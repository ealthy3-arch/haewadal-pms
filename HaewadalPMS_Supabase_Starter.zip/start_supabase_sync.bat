@echo off
setlocal EnableExtensions

set "SCRIPT_DIR=%~dp0"
set "SOURCE_ROOT="
set "PYTHON_CMD="

set "CONFIG_DIR=%APPDATA%\HaewadalPMS"
if not exist "%CONFIG_DIR%" mkdir "%CONFIG_DIR%" >nul 2>&1
set "ENV_FILE=%CONFIG_DIR%\.env.supabase.local.cmd"

if exist "%SCRIPT_DIR%haewadal_pms\supabase_sync.py" set "SOURCE_ROOT=%SCRIPT_DIR%"
if "%SOURCE_ROOT%"=="" if exist "%USERPROFILE%\Desktop\codex-pms\haewadal_pms\supabase_sync.py" set "SOURCE_ROOT=%USERPROFILE%\Desktop\codex-pms\"

if "%SOURCE_ROOT%"=="" (
  echo [ERROR] Could not find haewadal_pms\supabase_sync.py.
  echo         This sync watcher requires codex-pms source folder.
  echo         If you only installed setup.exe, run PMS app first and use direct sync mode.
  pause
  exit /b 1
)

if exist "%ENV_FILE%" call "%ENV_FILE%"

if "%SUPABASE_URL%"=="" (
  set /p SUPABASE_URL=SUPABASE_URL (example: https://YOUR_PROJECT.supabase.co^) : 
)

if "%SUPABASE_SERVICE_ROLE_KEY%"=="" (
  set /p SUPABASE_SERVICE_ROLE_KEY=SUPABASE_SERVICE_ROLE_KEY : 
)

if "%SUPABASE_URL%"=="" (
  echo [ERROR] SUPABASE_URL is empty.
  pause
  exit /b 1
)

if "%SUPABASE_SERVICE_ROLE_KEY%"=="" (
  echo [ERROR] SUPABASE_SERVICE_ROLE_KEY is empty.
  pause
  exit /b 1
)

if "%SUPABASE_SYNC_INTERVAL_SEC%"=="" set "SUPABASE_SYNC_INTERVAL_SEC=3"
if "%SUPABASE_SYNC_REPLACE%"=="" set "SUPABASE_SYNC_REPLACE=1"

(
  echo @echo off
  echo set "SUPABASE_URL=%SUPABASE_URL%"
  echo set "SUPABASE_SERVICE_ROLE_KEY=%SUPABASE_SERVICE_ROLE_KEY%"
  echo set "SUPABASE_SYNC_INTERVAL_SEC=%SUPABASE_SYNC_INTERVAL_SEC%"
  echo set "SUPABASE_SYNC_REPLACE=%SUPABASE_SYNC_REPLACE%"
) > "%ENV_FILE%" 2>nul

if errorlevel 1 (
  echo [WARN] Could not save local config file: %ENV_FILE%
)

where python >nul 2>&1 && set "PYTHON_CMD=python"
if "%PYTHON_CMD%"=="" where py >nul 2>&1 && set "PYTHON_CMD=py -3"

if "%PYTHON_CMD%"=="" (
  echo [ERROR] Python runtime not found.
  pause
  exit /b 1
)

cd /d "%SOURCE_ROOT%haewadal_pms"
echo [Haewadal PMS] Supabase sync watcher starting...
echo [INFO] Source root: %SOURCE_ROOT%
if "%PYTHON_CMD%"=="python" (
  if "%SUPABASE_SYNC_REPLACE%"=="0" (
    python supabase_sync.py watch --interval %SUPABASE_SYNC_INTERVAL_SEC%
  ) else (
    python supabase_sync.py watch --interval %SUPABASE_SYNC_INTERVAL_SEC% --replace
  )
) else (
  if "%SUPABASE_SYNC_REPLACE%"=="0" (
    py -3 supabase_sync.py watch --interval %SUPABASE_SYNC_INTERVAL_SEC%
  ) else (
    py -3 supabase_sync.py watch --interval %SUPABASE_SYNC_INTERVAL_SEC% --replace
  )
)

if errorlevel 1 (
  echo [ERROR] Sync watcher stopped with an error.
  pause
)

endlocal

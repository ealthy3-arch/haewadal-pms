-- Supabase schema for Haewadal PMS sync bridge
-- Run in Supabase SQL Editor before first sync.

create table if not exists floors (
  id bigint primary key,
  floor_num integer unique not null,
  floor_name text not null,
  created_at text
);

create table if not exists rooms (
  id bigint primary key,
  floor_id bigint not null references floors(id) on delete cascade,
  room_number text unique not null,
  room_name text,
  room_type text,
  base_rate integer,
  status text,
  memo text,
  sort_order integer
);

create table if not exists stays (
  id bigint primary key,
  room_id bigint not null references rooms(id),
  room_number text not null,
  guest_name text,
  guest_phone text,
  guest_count integer,
  check_in text not null,
  check_out text,
  stay_type text,
  rate integer,
  payment_method text,
  payment_amount integer,
  approval_number text,
  payment_status text,
  cancelled_amount integer,
  cancelled_at text,
  memo text,
  created_at text
);

create table if not exists reservations (
  id bigint primary key,
  room_id bigint,
  room_number text,
  guest_name text not null,
  guest_phone text,
  check_in_date text not null,
  check_out_date text,
  stay_type text,
  rate integer,
  memo text,
  status text,
  created_at text
);

create table if not exists payments (
  id bigint primary key,
  stay_id bigint,
  method text,
  amount integer,
  received_amount integer,
  change_amount integer,
  approval_number text,
  status text,
  worker_name text,
  memo text,
  created_at text
);

create table if not exists payment_cancellations (
  id bigint primary key,
  stay_id bigint,
  room_number text,
  cancel_amount integer,
  cancel_reason text,
  cancelled_by text,
  cancel_approval_number text,
  original_payment_method text,
  original_payment_amount integer,
  original_approval_number text,
  cancelled_at text
);

create table if not exists terminal_settings (
  id bigint primary key,
  terminal_type text,
  terminal_id text,
  merchant_id text,
  merchant_name text,
  server_ip text,
  server_port integer,
  timeout integer,
  api_key text,
  secret_key text,
  use_receipt integer,
  updated_at text
);

create table if not exists app_settings (
  key text primary key,
  value text
);

create table if not exists audit_logs (
  id bigint primary key,
  action text not null,
  target text,
  detail text,
  user_name text,
  created_at text
);


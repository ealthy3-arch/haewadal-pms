[해와달 PMS Supabase 스타터]

1) 이 스타터는 Supabase 연동 설정 도구입니다.
2) 먼저 해와달 PMS 설치/소스가 준비되어 있어야 합니다.
3) start_pms_with_supabase.bat 실행:
   - SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY를 처음 1회 입력
   - 자동으로 .env.supabase.local.cmd 파일에 저장
4) start_supabase_sync.bat 실행:
   - Supabase 동기화 워처를 별도 실행하고 싶을 때 사용

문제 해결:
- 창이 바로 닫히면 배치파일을 더블클릭하지 말고 cmd에서 실행해 메시지를 확인하세요.
- codex-pms 폴더를 찾지 못하면 Desktop\codex-pms 경로를 확인하세요.


-- ════════════════════════════════════════════════════════════════
-- 해와달 모텔 PMS v7.0 — Supabase 클라우드 DB 초기화 SQL
-- ════════════════════════════════════════════════════════════════
-- 사용법:
--   1. https://supabase.com 로그인
--   2. 좌측 메뉴 → SQL Editor
--   3. 아래 SQL을 전체 복사 후 붙여넣기
--   4. Run (F5) 버튼 클릭
-- ════════════════════════════════════════════════════════════════

-- 층 테이블
CREATE TABLE IF NOT EXISTS floors (
    id         BIGSERIAL PRIMARY KEY,
    floor_num  INTEGER UNIQUE NOT NULL,
    floor_name TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 객실 테이블
CREATE TABLE IF NOT EXISTS rooms (
    id          BIGSERIAL PRIMARY KEY,
    floor_id    BIGINT REFERENCES floors(id) ON DELETE CASCADE,
    room_number TEXT UNIQUE NOT NULL,
    room_name   TEXT DEFAULT '',
    room_type   TEXT DEFAULT '일반실',
    base_rate   INTEGER DEFAULT 50000,
    status      TEXT DEFAULT 'vacant',
    memo        TEXT DEFAULT '',
    sort_order  INTEGER DEFAULT 0
);

-- 투숙/결제 이력
CREATE TABLE IF NOT EXISTS stays (
    id              BIGSERIAL PRIMARY KEY,
    room_id         BIGINT REFERENCES rooms(id),
    room_number     TEXT,
    guest_name      TEXT DEFAULT '손님',
    guest_phone     TEXT DEFAULT '',
    guest_count     INTEGER DEFAULT 1,
    check_in        TIMESTAMPTZ,
    check_out       TIMESTAMPTZ,
    stay_type       TEXT DEFAULT '숙박',
    rate            INTEGER DEFAULT 0,
    payment_method  TEXT DEFAULT '',
    payment_amount  INTEGER DEFAULT 0,
    approval_number TEXT DEFAULT '',
    memo            TEXT DEFAULT '',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- 예약
CREATE TABLE IF NOT EXISTS reservations (
    id             BIGSERIAL PRIMARY KEY,
    room_number    TEXT DEFAULT '',
    guest_name     TEXT NOT NULL,
    guest_phone    TEXT DEFAULT '',
    check_in_date  TEXT NOT NULL,
    check_out_date TEXT DEFAULT '',
    stay_type      TEXT DEFAULT '숙박',
    rate           INTEGER DEFAULT 0,
    memo           TEXT DEFAULT '',
    status         TEXT DEFAULT 'confirmed',
    created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- 변경 로그
CREATE TABLE IF NOT EXISTS change_log (
    id         BIGSERIAL PRIMARY KEY,
    log_time   TIMESTAMPTZ DEFAULT NOW(),
    category   TEXT,
    action     TEXT,
    target     TEXT,
    before_val TEXT DEFAULT '',
    after_val  TEXT DEFAULT ''
);

-- ── 익명 접근 허용 (RLS 비활성화 — 판매용 단순 설정) ──────────
ALTER TABLE floors        DISABLE ROW LEVEL SECURITY;
ALTER TABLE rooms         DISABLE ROW LEVEL SECURITY;
ALTER TABLE stays         DISABLE ROW LEVEL SECURITY;
ALTER TABLE reservations  DISABLE ROW LEVEL SECURITY;
ALTER TABLE change_log    DISABLE ROW LEVEL SECURITY;

-- ── 기본 샘플 데이터 ──────────────────────────────────────────
INSERT INTO floors (floor_num, floor_name) VALUES (2,'2층'),(3,'3층'),(4,'4층')
ON CONFLICT (floor_num) DO NOTHING;

-- ════════════════════════════════════════════════════════════════
-- 완료! PMS에서 Settings → API → URL과 anon key를 복사해서 입력하세요
-- ════════════════════════════════════════════════════════════════

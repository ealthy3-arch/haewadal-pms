@echo off
chcp 65001 > nul
title 해와달 PMS EXE 빌드
echo.
echo  ╔══════════════════════════════════════════╗
echo  ║   해와달 모텔 PMS v7.1  EXE 빌드        ║
echo  ╚══════════════════════════════════════════╝
echo.
python --version > nul 2>&1
if %errorlevel% neq 0 ( echo Python 없음. pause & exit /b )
pip install pyinstaller -q
echo  빌드 중 (1~2분)...
pyinstaller --onefile --windowed --name "해와달_모텔_PMS_v7.1" ^
  --hidden-import tkinter --hidden-import tkinter.ttk ^
  --hidden-import sqlite3 haewadal_pms.py
if %errorlevel%==0 (
    echo.
    echo  ✅ 빌드 완료!  dist\해와달_모텔_PMS_v7.1.exe
) else ( echo  ❌ 빌드 실패 )
pause

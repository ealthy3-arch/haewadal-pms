@echo off
chcp 65001 > nul
title 해와달 모텔 PMS v7.1
color 0A
echo.
echo  ╔════════════════════════════════════════════╗
echo  ║      해와달 모텔 PMS v7.1  시작 중        ║
echo  ║  데이터: %%APPDATA%%\HaeWaDalPMS\           ║
echo  ╚════════════════════════════════════════════╝
echo.
python --version > nul 2>&1
if %errorlevel% neq 0 (
    echo  Python 없음 → https://python.org 설치 후 재실행
    echo  설치 시 "Add Python to PATH" 체크 필수!
    set /p x="지금 다운로드? [Y/N]: "
    if /i "%x%"=="Y" start https://www.python.org/downloads/
    pause & exit /b
)
cd /d "%~dp0"
echo  데이터: %APPDATA%\HaeWaDalPMS
echo.
python haewadal_pms.py
if %errorlevel% neq 0 (
    echo.
    echo  오류 발생 — %APPDATA%\HaeWaDalPMS\error.log 확인
    pause
)

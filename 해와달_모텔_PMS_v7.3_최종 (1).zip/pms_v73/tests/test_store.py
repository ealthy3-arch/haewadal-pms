"""해와달 모텔 PMS — MotelStore 단위 테스트 v7.2
리뷰 P0/P1 전 항목 검증 + 신규 기능 (환불/노쇼/일마감/마스킹/점검·고장)
"""
import os, tempfile, unittest
from datetime import date

from windows_app.motel_manager import (
    MotelStore,
    STATUS_AVAILABLE, STATUS_OCCUPIED, STATUS_CLEANING,
    STATUS_INSPECTION, STATUS_BROKEN,
    CHECKOUT_NORMAL, CHECKOUT_NOSHOW, CHECKOUT_REFUND,
    mask_phone,
)


# ── 헬퍼 ─────────────────────────────────────────────────────────
def _make_store():
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    return MotelStore(tmp.name), tmp.name

class _Base(unittest.TestCase):
    def setUp(self):    self.store, self.db = _make_store()
    def tearDown(self): self.store.conn.close(); os.unlink(self.db)
    def _ci(self, rn="101", name="홍길동", phone="01012345678", price=70000):
        self.store.check_in(rn, name, phone, "", price)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 1. 기존 제공 테스트 (원본 호환)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class OriginalTest(_Base):
    def test_seed_rooms(self):
        self.assertEqual(len(self.store.list_rooms()), 30)

    def test_checkin_checkout_flow(self):
        target = "101"
        self.store.check_in(target, "홍길동", "01012341234", "", 70000)
        room = next(r for r in self.store.list_rooms() if r.room_number == target)
        self.assertEqual(room.status, STATUS_OCCUPIED)
        self.assertEqual(room.guest_name, "홍길동")
        self.store.check_out(target)
        room = next(r for r in self.store.list_rooms() if r.room_number == target)
        self.assertEqual(room.status, STATUS_AVAILABLE)
        self.assertGreaterEqual(self.store.stats()["today_revenue"], 70000)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 2. P0: 상태 전이 방어
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class StatusTransitionTest(_Base):
    def test_checkout_noop_on_available_room(self):
        self.assertIsNone(self.store.check_out("101"))

    def test_cleaning_then_available(self):
        self.store.set_cleaning("201")
        self.assertEqual(next(r for r in self.store.list_rooms() if r.room_number == "201").status, STATUS_CLEANING)
        self.store.set_available("201")
        self.assertEqual(next(r for r in self.store.list_rooms() if r.room_number == "201").status, STATUS_AVAILABLE)

    def test_checkin_clears_on_checkout(self):
        self._ci()
        self.store.check_out("101")
        room = next(r for r in self.store.list_rooms() if r.room_number == "101")
        self.assertEqual(room.guest_name, ""); self.assertEqual(room.price, 0)

    def test_invalid_status_raises(self):
        with self.assertRaises(ValueError):
            self.store._set_status("101", "UNKNOWN")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 3. P1 신규: 점검중 / 고장 상태
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class InspectionBrokenTest(_Base):
    def test_set_inspection(self):
        self.store.set_inspection("301")
        self.assertEqual(next(r for r in self.store.list_rooms() if r.room_number == "301").status, STATUS_INSPECTION)

    def test_set_broken(self):
        self.store.set_broken("302")
        self.assertEqual(next(r for r in self.store.list_rooms() if r.room_number == "302").status, STATUS_BROKEN)

    def test_stats_all_statuses_sum_to_30(self):
        self.store.set_inspection("301"); self.store.set_broken("302")
        s = self.store.stats()
        self.assertEqual(s["inspection"], 1); self.assertEqual(s["broken"], 1)
        self.assertEqual(s["available"] + s["occupied"] + s["cleaning"] + s["inspection"] + s["broken"], 30)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 4. P1 신규: 노쇼
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class NoShowTest(_Base):
    def test_noshow_type_and_penalty(self):
        self._ci(price=80000)
        rec = self.store.check_out_noshow("101", penalty=20000)
        self.assertIsNotNone(rec)
        self.assertEqual(rec.checkout_type, CHECKOUT_NOSHOW)
        self.assertEqual(rec.final_price, 20000)

    def test_noshow_frees_room(self):
        self._ci()
        self.store.check_out_noshow("101")
        self.assertEqual(next(r for r in self.store.list_rooms() if r.room_number == "101").status, STATUS_AVAILABLE)

    def test_noshow_noop_on_empty_room(self):
        self.assertIsNone(self.store.check_out_noshow("201"))

    def test_noshow_zero_penalty(self):
        self._ci(price=60000)
        rec = self.store.check_out_noshow("101", penalty=0)
        self.assertEqual(rec.final_price, 0)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 5. P1 신규: 환불
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class RefundTest(_Base):
    def _sid(self, price=100000):
        self._ci(price=price)
        return self.store.check_out("101").id

    def test_partial_refund(self):
        sid = self._sid()
        self.assertTrue(self.store.refund_stay(sid, 30000))
        row = self.store.conn.execute("SELECT refund_amount, checkout_type FROM stay_history WHERE id=?", (sid,)).fetchone()
        self.assertEqual(row["refund_amount"], 30000)
        self.assertEqual(row["checkout_type"], CHECKOUT_REFUND)

    def test_full_refund(self):
        sid = self._sid(price=50000)
        self.store.refund_stay(sid, 50000)
        self.assertEqual(self.store.conn.execute("SELECT refund_amount FROM stay_history WHERE id=?", (sid,)).fetchone()["refund_amount"], 50000)

    def test_over_refund_raises(self):
        with self.assertRaises(ValueError):
            self.store.refund_stay(self._sid(price=50000), 999999)

    def test_invalid_id_returns_false(self):
        self.assertFalse(self.store.refund_stay(99999, 1000))

    def test_cumulative_refund_limit(self):
        sid = self._sid(price=60000)
        self.store.refund_stay(sid, 40000)
        with self.assertRaises(ValueError):
            self.store.refund_stay(sid, 30000)   # 40000+30000 > 60000


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 6. P1 신규: 일마감 정산 리포트
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class DailyReportTest(_Base):
    def setUp(self):
        super().setUp()
        self.today = date.today().isoformat()
        # 정상 체크아웃
        self.store.check_in("101","A","01011111111","",70000); self.store.check_out("101")
        # 노쇼
        self.store.check_in("201","B","01022222222","",80000); self.store.check_out_noshow("201", penalty=20000)
        # 환불
        self.store.check_in("301","C","01033333333","",60000)
        rec = self.store.check_out("301")
        self.store.refund_stay(rec.id, 10000)

    def test_counts(self):
        rpt = self.store.daily_report(self.today)
        self.assertEqual(rpt.total_checkouts, 3)
        self.assertEqual(rpt.normal_count, 1)
        self.assertEqual(rpt.noshow_count, 1)
        self.assertEqual(rpt.refund_count, 1)

    def test_revenue(self):
        rpt = self.store.daily_report(self.today)
        self.assertEqual(rpt.gross_revenue, 150000)   # 70000+20000+60000
        self.assertEqual(rpt.total_refunds, 10000)
        self.assertEqual(rpt.net_revenue, 140000)

    def test_phone_masking_in_report(self):
        rpt = self.store.daily_report(self.today)
        for b in rpt.room_breakdown:
            self.assertTrue("*" in b["guest_phone"] or b["guest_phone"] == "",
                            f"마스킹 실패: {b['guest_phone']!r}")

    def test_empty_day(self):
        rpt = self.store.daily_report("2000-01-01")
        self.assertEqual(rpt.total_checkouts, 0)
        self.assertEqual(rpt.net_revenue, 0)

    def test_csv_export(self):
        csv_str = self.store.export_daily_report_csv(self.today)
        self.assertIn("날짜", csv_str)
        self.assertIn(self.today, csv_str)
        self.assertIn("순매출", csv_str)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 7. P1 신규: 전화번호 마스킹 유틸
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class MaskPhoneTest(unittest.TestCase):
    def test_11_digits(self):     self.assertEqual(mask_phone("01012345678"),  "010-****-5678")
    def test_10_digits(self):     self.assertEqual(mask_phone("0101234567"),   "010-***-4567")
    def test_with_dashes(self):   self.assertEqual(mask_phone("010-1234-5678"),"010-****-5678")
    def test_empty(self):         self.assertEqual(mask_phone(""),              "")
    def test_rawdigit_in_result(self): self.assertIn("1234", mask_phone("1234"))

    def test_masked_in_roomview(self):
        store, db = _make_store()
        store.check_in("101","T","01099998888","",50000)
        room = next(r for r in store.list_rooms() if r.room_number == "101")
        self.assertIn("****", room.masked_phone)
        self.assertNotIn("9999", room.masked_phone)
        store.conn.close(); os.unlink(db)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 8. 기존: 매출 집계 정확성
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class RevenueTest(_Base):
    def test_multiple_checkouts(self):
        for rn, p in [("101",50000),("201",70000),("301",100000)]:
            self._ci(rn, price=p); self.store.check_out(rn)
        rpt = self.store.daily_report()
        self.assertEqual(rpt.gross_revenue, 220000)
        self.assertEqual(rpt.net_revenue, 220000)

    def test_only_today_counted(self):
        self._ci("102", price=80000); self.store.check_out("102")
        self.store.conn.execute(
            "INSERT INTO stay_history (room_number,guest_name,guest_phone,checkin_at,checkout_at,final_price,refund_amount,checkout_type,created_at) "
            "VALUES ('999','옛날','','2020-01-01T10:00:00','2020-01-01T12:00:00',999999,0,'normal','2020-01-01T12:00:00')"
        )
        self.store.conn.commit()
        self.assertEqual(self.store.daily_report().net_revenue, 80000)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 9. 기존: 이중 체크인 방어 / 통계 정합성
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class IdempotencyTest(_Base):
    def test_double_checkin_no_dup(self):
        self._ci(); self.store.check_in("101","두번째","",",",60000)
        rooms = [r for r in self.store.list_rooms() if r.room_number == "101"]
        self.assertEqual(len(rooms), 1)
        self.assertEqual(rooms[0].guest_name, "두번째")

    def test_stats_total_30(self):
        self._ci("101"); self.store.set_cleaning("201"); self.store.set_inspection("301"); self.store.set_broken("302")
        s = self.store.stats()
        self.assertEqual(s["available"]+s["occupied"]+s["cleaning"]+s["inspection"]+s["broken"], 30)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 10. 기존: 감사로그
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class AuditLogTest(_Base):
    def test_checkout_writes_history(self):
        self._ci("101", name="감사로그", phone="01011112222", price=75000)
        self.store.check_out("101")
        rows = self.store.conn.execute("SELECT * FROM stay_history WHERE room_number='101'").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(dict(rows[0])["final_price"], 75000)

    def test_available_room_no_history(self):
        self.store.check_out("201")
        self.assertEqual(self.store.conn.execute("SELECT COUNT(*) FROM stay_history WHERE room_number='201'").fetchone()[0], 0)


if __name__ == "__main__":
    unittest.main()

"""해와달 모텔 PMS — P2 기능 단위 테스트
RBAC (역할 기반 권한), 개인정보 라이프사이클(익명화), 스키마 마이그레이션
"""
import os, tempfile, unittest
from datetime import date, timedelta

from windows_app.motel_manager import (
    MotelStore, AuthManager,
    ROLE_ADMIN, ROLE_COUNTER, ROLE_CLEANING,
    ROLE_PERMISSIONS,
    mask_phone,
)


# ── 헬퍼 ─────────────────────────────────────────────────────────
def _store(retention_days=365):
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    return MotelStore(tmp.name, retention_days=retention_days), tmp.name

class _Base(unittest.TestCase):
    def setUp(self):    self.store, self.db = _store()
    def tearDown(self): self.store.conn.close(); os.unlink(self.db)
    def _ci(self, rn="101", name="홍길동", phone="01012345678", price=70000):
        self.store.check_in(rn, name, phone, "", price)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 1. 스키마 마이그레이션
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class SchemaMigrationTest(_Base):
    def test_schema_version_is_current(self):
        """마이그레이션 실행 후 버전이 SCHEMA_VERSION(3)이어야 함"""
        from windows_app.motel_manager import SCHEMA_VERSION
        self.assertEqual(self.store.schema_version(), SCHEMA_VERSION)

    def test_staff_table_exists(self):
        tables = {r[0] for r in self.store.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        self.assertIn("staff", tables)
        self.assertIn("access_log", tables)
        self.assertIn("privacy_policy", tables)

    def test_stay_history_has_anonymized_column(self):
        cols = {r[1] for r in self.store.conn.execute(
            "PRAGMA table_info(stay_history)"
        ).fetchall()}
        self.assertIn("anonymized", cols)

    def test_privacy_policy_seeded(self):
        row = self.store.conn.execute(
            "SELECT retention_days FROM privacy_policy WHERE id=1"
        ).fetchone()
        self.assertIsNotNone(row)
        self.assertGreater(row["retention_days"], 0)

    def test_idempotent_migration(self):
        """같은 DB에 두 번 마이그레이션해도 오류 없음"""
        store2 = MotelStore(self.db)   # 재접속 = 마이그레이션 재시도
        self.assertEqual(store2.schema_version(), self.store.schema_version())
        store2.conn.close()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 2. AuthManager — 계정 생성 / 로그인
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class AuthAccountTest(_Base):
    def setUp(self):
        super().setUp()
        self.auth = self.store.auth
        self.auth.create_staff("admin1", "1234", ROLE_ADMIN)
        self.auth.create_staff("counter1", "5678", ROLE_COUNTER)
        self.auth.create_staff("clean1", "9999", ROLE_CLEANING)

    def test_login_success(self):
        self.assertTrue(self.auth.login("admin1", "1234"))
        self.assertEqual(self.auth.current_user.role, ROLE_ADMIN)

    def test_login_wrong_pin(self):
        self.assertFalse(self.auth.login("admin1", "0000"))
        self.assertIsNone(self.auth.current_user)

    def test_login_unknown_user(self):
        self.assertFalse(self.auth.login("ghost", "1234"))

    def test_logout_clears_user(self):
        self.auth.login("admin1", "1234")
        self.auth.logout()
        self.assertIsNone(self.auth.current_user)
        self.assertFalse(self.auth.is_logged_in)

    def test_duplicate_username_raises(self):
        with self.assertRaises(ValueError):
            self.auth.create_staff("admin1", "9999", ROLE_COUNTER)

    def test_short_pin_raises(self):
        with self.assertRaises(ValueError):
            self.auth.create_staff("newuser", "12", ROLE_COUNTER)

    def test_invalid_role_raises(self):
        with self.assertRaises(ValueError):
            self.auth.create_staff("x", "1234", "god_mode")

    def test_change_pin(self):
        self.auth.change_pin("counter1", "newpin123")
        self.assertFalse(self.auth.login("counter1", "5678"))
        self.assertTrue(self.auth.login("counter1", "newpin123"))

    def test_deactivate(self):
        self.auth.deactivate("clean1")
        self.assertFalse(self.auth.login("clean1", "9999"))

    def test_list_staff_returns_all(self):
        accounts = self.auth.list_staff()
        usernames = {a.username for a in accounts}
        self.assertIn("admin1", usernames)
        self.assertIn("counter1", usernames)
        self.assertIn("clean1", usernames)

    def test_has_any_admin(self):
        self.assertTrue(self.auth.has_any_admin())


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 3. RBAC — 역할별 권한 검증
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class RBACPermissionTest(_Base):
    def setUp(self):
        super().setUp()
        self.auth = self.store.auth
        self.auth.create_staff("admin1",   "1111", ROLE_ADMIN)
        self.auth.create_staff("counter1", "2222", ROLE_COUNTER)
        self.auth.create_staff("clean1",   "3333", ROLE_CLEANING)

    def _login(self, username, pin):
        self.auth.login(username, pin)

    # 관리자: 모든 권한
    def test_admin_can_all(self):
        self._login("admin1", "1111")
        for action in ["checkin","checkout","noshow","refund",
                       "set_cleaning","set_inspection","set_broken","set_available",
                       "daily_report","export_csv","anonymize","manage_users"]:
            self.assertTrue(self.auth.can(action), f"admin should allow: {action}")

    # 카운터: 체크인/아웃/결제만
    def test_counter_can_checkin_checkout(self):
        self._login("counter1", "2222")
        for action in ["checkin","checkout","noshow","refund","daily_report","export_csv"]:
            self.assertTrue(self.auth.can(action), f"counter should allow: {action}")

    def test_counter_cannot_manage_users_or_anonymize(self):
        self._login("counter1", "2222")
        self.assertFalse(self.auth.can("manage_users"))
        self.assertFalse(self.auth.can("anonymize"))
        self.assertFalse(self.auth.can("set_broken"))

    # 청소: 상태 변경만
    def test_cleaning_can_set_status(self):
        self._login("clean1", "3333")
        self.assertTrue(self.auth.can("set_cleaning"))
        self.assertTrue(self.auth.can("set_available"))

    def test_cleaning_cannot_checkin_or_report(self):
        self._login("clean1", "3333")
        for action in ["checkin","checkout","noshow","refund","daily_report","anonymize","manage_users"]:
            self.assertFalse(self.auth.can(action), f"cleaning should deny: {action}")

    def test_require_raises_permission_error(self):
        self._login("clean1", "3333")
        with self.assertRaises(PermissionError):
            self.auth.require("checkin")

    def test_not_logged_in_denies_all(self):
        for action in ["checkin","checkout","set_cleaning","daily_report"]:
            self.assertFalse(self.auth.can(action))

    def test_role_permissions_completeness(self):
        """counter 권한은 cleaning 권한의 상위집합이어야 함"""
        self.assertTrue(
            ROLE_PERMISSIONS[ROLE_CLEANING].issubset(ROLE_PERMISSIONS[ROLE_COUNTER])
        )
        self.assertTrue(
            ROLE_PERMISSIONS[ROLE_COUNTER].issubset(ROLE_PERMISSIONS[ROLE_ADMIN])
        )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 4. 접근 로그 감사
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class AccessLogTest(_Base):
    def setUp(self):
        super().setUp()
        self.auth = self.store.auth
        self.auth.create_staff("admin1", "1234", ROLE_ADMIN)

    def test_login_logout_logged(self):
        self.auth.login("admin1", "1234")
        self.auth.logout()
        logs = self.auth.access_log()
        events = [l["event"] for l in logs]
        self.assertIn("login", events)
        self.assertIn("logout", events)

    def test_action_log_recorded(self):
        self.auth.login("admin1", "1234")
        self.auth.log_action("checkin", "101/홍길동")
        logs = self.auth.access_log()
        self.assertTrue(any("checkin" in l["event"] for l in logs))

    def test_log_contains_username_and_role(self):
        self.auth.login("admin1", "1234")
        log = self.auth.access_log(limit=1)[0]
        self.assertEqual(log["username"], "admin1")
        self.assertEqual(log["role"], ROLE_ADMIN)

    def test_failed_login_not_logged(self):
        """실패한 로그인은 access_log에 기록되지 않아야 함"""
        self.auth.login("admin1", "wrong")
        logs = self.auth.access_log()
        self.assertEqual(len(logs), 0)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 5. 개인정보 보관 정책
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class PrivacyPolicyTest(_Base):
    def test_default_retention(self):
        self.assertEqual(self.store.get_retention_policy(), 365)

    def test_set_retention(self):
        self.store.set_retention_policy(180)
        self.assertEqual(self.store.get_retention_policy(), 180)

    def test_too_short_retention_raises(self):
        with self.assertRaises(ValueError):
            self.store.set_retention_policy(10)

    def test_minimum_30_days_allowed(self):
        self.store.set_retention_policy(30)
        self.assertEqual(self.store.get_retention_policy(), 30)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 6. 개인정보 익명화
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
class AnonymizationTest(_Base):
    def _insert_old_record(self, days_ago: int, room="101", name="옛날고객", phone="01099998888"):
        """days_ago일 전 체크아웃 기록을 직접 삽입"""
        co = (date.today() - timedelta(days=days_ago)).isoformat()
        self.store.conn.execute("""
            INSERT INTO stay_history
                (room_number, guest_name, guest_phone, checkin_at, checkout_at,
                 final_price, refund_amount, checkout_type, anonymized, created_at)
            VALUES (?, ?, ?, ?, ?, 50000, 0, 'normal', 0, ?)
        """, (room, name, phone, co + "T10:00:00", co + "T12:00:00", co + "T12:00:00"))
        self.store.conn.commit()

    def test_anonymize_old_records(self):
        """보관 기간 초과 레코드가 익명화됨"""
        self._insert_old_record(400)   # 400일 전 → 365일 정책 초과
        n = self.store.anonymize_old_records()
        self.assertEqual(n, 1)
        row = self.store.conn.execute(
            "SELECT guest_name, guest_phone, anonymized FROM stay_history"
        ).fetchone()
        self.assertEqual(row["guest_name"], "[익명]")
        self.assertEqual(row["guest_phone"], "")
        self.assertEqual(row["anonymized"], 1)

    def test_recent_records_not_anonymized(self):
        """보관 기간 내 레코드는 익명화되지 않음"""
        self._insert_old_record(30)    # 30일 전 → 365일 정책 이내
        n = self.store.anonymize_old_records()
        self.assertEqual(n, 0)
        row = self.store.conn.execute("SELECT guest_name FROM stay_history").fetchone()
        self.assertEqual(row["guest_name"], "옛날고객")   # 원본 유지

    def test_already_anonymized_not_counted_again(self):
        """이미 익명화된 레코드는 다시 카운트되지 않음"""
        self._insert_old_record(400)
        first  = self.store.anonymize_old_records()
        second = self.store.anonymize_old_records()
        self.assertEqual(first, 1)
        self.assertEqual(second, 0)   # 이미 처리됨

    def test_custom_cutoff_date(self):
        """특정 날짜 기준 익명화 — 경계값 검증"""
        self._insert_old_record(5,   room="102")   # 5일 전  → 기준일(9일) 이내
        self._insert_old_record(15,  room="201")   # 15일 전 → 기준일(9일) 초과
        self._insert_old_record(200, room="301")   # 200일 전 → 기준일(9일) 초과

        nine_days_ago = (date.today() - timedelta(days=9)).isoformat()
        n = self.store.anonymize_old_records(before_date=nine_days_ago)

        # 5일 전 레코드는 기준일(9일) 이내 → 익명화 안 됨
        # 15일·200일 전 레코드는 초과 → 익명화
        self.assertEqual(n, 2)

        # 5일 전 레코드 원본 유지 확인
        row = self.store.conn.execute(
            "SELECT guest_name, anonymized FROM stay_history WHERE room_number='102'"
        ).fetchone()
        self.assertEqual(row["guest_name"], "옛날고객")
        self.assertEqual(row["anonymized"], 0)

    def test_anonymization_stats(self):
        self._insert_old_record(400, room="101")
        self._insert_old_record(30,  room="201")
        self.store.anonymize_old_records()
        stats = self.store.anonymization_stats()
        self.assertEqual(stats["anonymized"], 1)
        self.assertEqual(stats["active"], 1)

    def test_today_record_never_anonymized(self):
        """당일 체크아웃 이력은 절대 익명화되지 않음"""
        self._ci(); self.store.check_out("101")
        n = self.store.anonymize_old_records()
        self.assertEqual(n, 0)

    def test_custom_retention_overrides_policy(self):
        """호출 시 retention_days 인자를 전달하면 DB 정책 무시"""
        self._insert_old_record(20)   # 20일 전
        n = self.store.anonymize_old_records(retention_days=15)   # 15일 기준
        self.assertEqual(n, 1)   # 20 > 15이므로 익명화

    def test_phone_empty_after_anonymization(self):
        self._insert_old_record(400)
        self.store.anonymize_old_records()
        row = self.store.conn.execute("SELECT guest_phone FROM stay_history").fetchone()
        self.assertEqual(row["guest_phone"], "")


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════╗
║   해와달 모텔 PMS (객실관리시스템) v7.0                          ║
║   Haewadal Motel Property Management System                      ║
║   ─────────────────────────────────────────                      ║
║   • 클라우드 DB (Supabase) 실시간 동기화                         ║
║   • 오프라인 로컬 SQLite 자동 전환                               ║
║   • Windows AppData 영구저장 (재시작 후에도 유지)                ║
║   • 다중 장치 동시 사용 지원                                     ║
║   • 판매용 — 구매자별 개별 DB 구성                               ║
╚══════════════════════════════════════════════════════════════════╝
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import sqlite3
import json
import os
import sys
import time
import datetime
import threading
import urllib.request
import urllib.error
import urllib.parse
import socket
import shutil
import csv
import logging
import subprocess
import traceback
from pathlib import Path

# ═══════════════════════════════════════════════════════════════════
# 경로 설정  ─  AppData 사용으로 데이터 영구저장 보장
# ═══════════════════════════════════════════════════════════════════
APP_NAME    = "해와달 모텔 PMS"
APP_VERSION = "7.1.0"

def get_data_dir() -> Path:
    """운영체제에 맞는 영구 데이터 폴더 반환"""
    if sys.platform == 'win32':
        base = Path(os.environ.get('APPDATA', Path.home()))
    elif sys.platform == 'darwin':
        base = Path.home() / 'Library' / 'Application Support'
    else:
        base = Path.home() / '.config'
    d = base / 'HaeWaDalPMS'
    d.mkdir(parents=True, exist_ok=True)
    return d

DATA_DIR    = get_data_dir()
CONFIG_FILE = DATA_DIR / 'config.json'
DB_FILE     = DATA_DIR / 'haewadal_pms.db'
LOG_FILE    = DATA_DIR / 'changelog.txt'
ERROR_LOG   = DATA_DIR / 'error.log'

# ═══ 에러 로깅 설정 ════════════════════════════════════════════════
import logging as _logging, traceback as _traceback
_logging.basicConfig(
    filename=str(ERROR_LOG), level=_logging.ERROR,
    format='%(asctime)s [%(levelname)s] %(message)s', encoding='utf-8',
)
_logger = _logging.getLogger('haewadal_pms')

def log_error(msg: str, exc=None):
    if exc:
        _logger.error("%s\n%s", msg, _traceback.format_exc())
    else:
        _logger.error(msg)

# ───────── 색상 ─────────────────────────────────────────────────
C = {
    'bg':     '#1a1a2e', 'panel':  '#16213e', 'card':   '#0f3460',
    'accent': '#e94560', 'teal':   '#0f9b8e', 'white':  '#ffffff',
    'gray':   '#a0a0b0', 'yellow': '#ffd700', 'green':  '#27ae60',
    'red':    '#e74c3c', 'blue':   '#2980b9', 'orange': '#e67e22',
    'dgray':  '#555577', 'dark':   '#2a2a4a',
}

STATUS_MAP = {
    'vacant':       ('공실',   '#27ae60', '⬜'),
    'occupied':     ('사용중', '#e74c3c', '🔴'),
    'reserved':     ('예약',   '#f39c12', '🟡'),
    'cleaning':     ('청소중', '#8e44ad', '🟣'),
    'out_of_order': ('수리중', '#7f8c8d', '⚫'),
}

# ═══════════════════════════════════════════════════════════════════
# 설정 관리자
# ═══════════════════════════════════════════════════════════════════
class Config:
    DEFAULTS = {
        'motel_name':     '해와달 모텔',
        'motel_address':  '강원도 강릉시',
        'motel_phone':    '',
        'checkin_time':   '14:00',
        'checkout_time':  '11:00',
        'supabase_url':   '',
        'supabase_key':   '',
        'use_cloud':      False,
        'cloud_verified': False,
        # 직원 인증
        'use_pin_auth':   False,
        'admin_pin_hash': '',   # sha256(PIN)
        'staff_pins':     {},   # {이름: sha256(PIN)}
    }
    def __init__(self):
        self._d = dict(self.DEFAULTS)
        self._load()

    def _load(self):
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, encoding='utf-8') as f:
                    self._d.update(json.load(f))
            except Exception:
                pass

    def save(self):
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(self._d, f, ensure_ascii=False, indent=2)

    def __getitem__(self, k): return self._d.get(k, self.DEFAULTS.get(k))
    def __setitem__(self, k, v): self._d[k] = v
    def get(self, k, default=None): return self._d.get(k, default)

# ═══════════════════════════════════════════════════════════════════
# Supabase REST API 클라이언트 (외부 라이브러리 불필요)
# ═══════════════════════════════════════════════════════════════════
class SupabaseClient:
    def __init__(self, url: str, key: str):
        self.url  = url.rstrip('/')
        self.key  = key
        self._ok  = False

    def _headers(self, extra=None):
        h = {
            'apikey': self.key,
            'Authorization': f'Bearer {self.key}',
            'Content-Type': 'application/json',
            'Prefer': 'return=representation',
        }
        if extra: h.update(extra)
        return h

    def _req(self, method, path, data=None, params=None, timeout=10):
        url = self.url + '/rest/v1/' + path
        if params:
            url += '?' + urllib.parse.urlencode(params)
        body = json.dumps(data).encode() if data else None
        req  = urllib.request.Request(url, data=body,
                                       headers=self._headers(), method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read()
                return json.loads(raw) if raw else []
        except urllib.error.HTTPError as e:
            body = e.read().decode(errors='replace')
            raise RuntimeError(f"HTTP {e.code}: {body}")

    def ping(self):
        """연결 테스트"""
        try:
            self._req('GET', 'floors', params={'limit': '1'})
            self._ok = True
            return True
        except Exception:
            self._ok = False
            return False

    def select(self, table, eq=None, order=None, limit=None):
        p = {}
        if eq:
            for k, v in eq.items(): p[k] = f'eq.{v}'
        if order: p['order']= order
        if limit: p['limit']= str(limit)
        return self._req('GET', table, params=p) or []

    def insert(self, table, row):
        r = self._req('POST', table, data=row)
        return r[0] if isinstance(r, list) and r else r

    def update(self, table, row, eq: dict):
        p = {k: f'eq.{v}' for k, v in eq.items()}
        r = self._req('PATCH', table, data=row, params=p)
        return r[0] if isinstance(r, list) and r else r

    def delete(self, table, eq: dict):
        p = {k: f'eq.{v}' for k, v in eq.items()}
        return self._req('DELETE', table, params=p)

    def upsert(self, table, rows, on_conflict='id'):
        if not isinstance(rows, list): rows = [rows]
        self._req('POST', table, data=rows,
                  extra_h={'Prefer': f'resolution=merge-duplicates,return=representation'})


# ═══════════════════════════════════════════════════════════════════
# 직원 PIN 인증 (선택 사용)
# ═══════════════════════════════════════════════════════════════════
import hashlib as _hashlib

def _pin_hash(pin: str) -> str:
    return _hashlib.sha256(pin.encode()).hexdigest()

class PinAuthDialog(tk.Toplevel):
    """PIN 입력 다이얼로그 — 확인/취소 반환"""
    def __init__(self, parent, cfg: "Config", role="any"):
        super().__init__(parent)
        self.cfg = cfg; self.role = role; self.result = False
        self.title("직원 인증"); self.geometry("300x220")
        self.configure(bg=C["bg"]); self.resizable(False, False)
        self.transient(parent); self.grab_set()
        self._ui()

    def _ui(self):
        lbl(self, "🔐 PIN 번호를 입력하세요", C["yellow"], 12, True).pack(pady=(20,8))
        self._pin = tk.StringVar()
        e = entry(self, self._pin, w=14, font_size=16)
        e.config(show="●"); e.pack(pady=8); e.focus_set()
        e.bind("<Return>", lambda _: self._check())
        bf = tk.Frame(self, bg=C["bg"]); bf.pack(pady=10)
        btn(bf, "확인",  self._check,  C["green"], px=16, py=7).pack(side="left", padx=6)
        btn(bf, "취소",  self.destroy, C["dgray"], px=14, py=7).pack(side="left", padx=6)

    def _check(self):
        h = _pin_hash(self._pin.get().strip())
        ok = False
        if h == self.cfg["admin_pin_hash"]:
            ok = True
        else:
            for name, ph in self.cfg.get("staff_pins", {}).items():
                if h == ph:
                    ok = True; break
        if ok:
            self.result = True; self.destroy()
        else:
            messagebox.showerror("인증 실패", "PIN이 올바르지 않습니다.", parent=self)
            self._pin.set("")

    @classmethod
    def ask(cls, parent, cfg, role="any") -> bool:
        if not cfg["use_pin_auth"]:
            return True
        dlg = cls(parent, cfg, role)
        parent.wait_window(dlg)
        return dlg.result


class PinSettingsDlg(tk.Toplevel):
    """PIN 관리 다이얼로그"""
    def __init__(self, parent, cfg: "Config"):
        super().__init__(parent)
        self.cfg = cfg; self.title("직원 PIN 관리")
        self.geometry("400x420"); self.configure(bg=C["bg"])
        self.resizable(False, False); self.transient(parent); self.grab_set()
        self._ui()

    def _ui(self):
        lbl(self, "🔐 직원 PIN 인증 설정", C["yellow"], 13, True).pack(pady=(14,6))
        self.use_v = tk.BooleanVar(value=self.cfg["use_pin_auth"])
        tk.Checkbutton(self, text="  PIN 인증 사용 (체크하면 주요 작업에 PIN 필요)",
                       variable=self.use_v, bg=C["bg"], fg="white",
                       selectcolor=C["dark"], activebackground=C["bg"],
                       font=("맑은 고딕", 10)).pack(anchor="w", padx=20, pady=4)
        fm = tk.LabelFrame(self, text=" 관리자 PIN ", bg=C["panel"],
                           fg=C["yellow"], font=("맑은 고딕", 9, "bold"))
        fm.pack(fill="x", padx=20, pady=6)
        r = tk.Frame(fm, bg=C["panel"]); r.pack(padx=10, pady=8)
        lbl(r, "새 PIN (4~8자리):").pack(side="left")
        self.ap = tk.StringVar(); e = entry(r, self.ap, w=10); e.config(show="●"); e.pack(side="left", padx=8)
        btn(r, "저장", self._save_admin, C["blue"], px=10, py=4, fs=9).pack(side="left")
        self.al = lbl(fm, "현재 상태: " + ("설정됨" if self.cfg["admin_pin_hash"] else "미설정"),
                      C["gray"], 9); self.al.pack(pady=4)
        sf = tk.LabelFrame(self, text=" 직원 PIN 추가 ", bg=C["panel"],
                           fg=C["yellow"], font=("맑은 고딕", 9, "bold"))
        sf.pack(fill="x", padx=20, pady=6)
        r2 = tk.Frame(sf, bg=C["panel"]); r2.pack(padx=10, pady=8)
        lbl(r2, "이름:").pack(side="left")
        self.sn = tk.StringVar(); entry(r2, self.sn, w=8).pack(side="left", padx=4)
        lbl(r2, "PIN:").pack(side="left", padx=(8,0))
        self.sp = tk.StringVar(); e2 = entry(r2, self.sp, w=8); e2.config(show="●"); e2.pack(side="left", padx=4)
        btn(r2, "추가", self._add_staff, C["green"], px=8, py=4, fs=9).pack(side="left")
        self.list_f = tk.Frame(sf, bg=C["panel"]); self.list_f.pack(fill="x", padx=10, pady=4)
        self._refresh_list()
        btn(self, "💾 저장 후 닫기", self._done, C["green"], px=16, py=8).pack(pady=10)

    def _save_admin(self):
        p = self.ap.get().strip()
        if len(p) < 4: messagebox.showerror("오류", "4자리 이상 입력하세요.", parent=self); return
        self.cfg["admin_pin_hash"] = _pin_hash(p)
        self.al.config(text="현재 상태: 설정됨 ✅"); self.ap.set("")

    def _add_staff(self):
        n = self.sn.get().strip(); p = self.sp.get().strip()
        if not n or len(p) < 4: messagebox.showerror("오류", "이름과 PIN(4자+)을 입력하세요.", parent=self); return
        pins = dict(self.cfg.get("staff_pins", {})); pins[n] = _pin_hash(p)
        self.cfg["staff_pins"] = pins; self.sn.set(""); self.sp.set(""); self._refresh_list()

    def _refresh_list(self):
        for w in self.list_f.winfo_children(): w.destroy()
        for name in self.cfg.get("staff_pins", {}):
            r = tk.Frame(self.list_f, bg=C["panel"]); r.pack(fill="x")
            lbl(r, f"  👤 {name}", C["white"], 9).pack(side="left")
            btn(r, "삭제", lambda n=name: self._del(n), C["red"], px=6, py=2, fs=8).pack(side="right")

    def _del(self, name):
        pins = dict(self.cfg.get("staff_pins", {})); pins.pop(name, None)
        self.cfg["staff_pins"] = pins; self._refresh_list()

    def _done(self):
        self.cfg["use_pin_auth"] = self.use_v.get(); self.cfg.save(); self.destroy()


# ═══════════════════════════════════════════════════════════════════
# 로컬 SQLite DB (오프라인 / 캐시 / 클라우드 없을 때 단독 사용)
# ═══════════════════════════════════════════════════════════════════
class LocalDB:
    def __init__(self):
        self.path = str(DB_FILE)
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._init()
        self._seed()

    def _init(self):
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.conn.executescript(f"""
        CREATE TABLE IF NOT EXISTS floors (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            floor_num  INTEGER UNIQUE NOT NULL,
            floor_name TEXT NOT NULL,
            created_at TEXT DEFAULT '{now}'
        );
        CREATE TABLE IF NOT EXISTS rooms (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            floor_id    INTEGER NOT NULL,
            room_number TEXT UNIQUE NOT NULL,
            room_name   TEXT DEFAULT '',
            room_type   TEXT DEFAULT '일반실',
            base_rate   INTEGER DEFAULT 50000,
            status      TEXT DEFAULT 'vacant',
            memo        TEXT DEFAULT '',
            sort_order  INTEGER DEFAULT 0,
            FOREIGN KEY (floor_id) REFERENCES floors(id)
        );
        CREATE TABLE IF NOT EXISTS stays (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id         INTEGER,
            room_number     TEXT,
            guest_name      TEXT DEFAULT '손님',
            guest_phone     TEXT DEFAULT '',
            guest_count     INTEGER DEFAULT 1,
            check_in        TEXT,
            check_out       TEXT,
            stay_type       TEXT DEFAULT '숙박',
            rate            INTEGER DEFAULT 0,
            payment_method  TEXT DEFAULT '',
            payment_amount  INTEGER DEFAULT 0,
            approval_number TEXT DEFAULT '',
            memo            TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS reservations (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            room_number    TEXT DEFAULT '',
            guest_name     TEXT,
            guest_phone    TEXT DEFAULT '',
            check_in_date  TEXT,
            check_out_date TEXT DEFAULT '',
            stay_type      TEXT DEFAULT '숙박',
            rate           INTEGER DEFAULT 0,
            memo           TEXT DEFAULT '',
            status         TEXT DEFAULT 'confirmed'
        );
        CREATE TABLE IF NOT EXISTS change_log (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            log_time   TEXT,
            category   TEXT,
            action     TEXT,
            target     TEXT,
            before_val TEXT DEFAULT '',
            after_val  TEXT DEFAULT ''
        );
        """)
        self.conn.commit()

    def _seed(self):
        if self._one("SELECT COUNT(*) as n FROM floors")['n'] > 0:
            return
        c = self.conn.cursor()
        for fl in range(2, 5):
            c.execute("INSERT INTO floors(floor_num,floor_name) VALUES(?,?)", (fl, f"{fl}층"))
            fid = c.lastrowid
            items = [
                ('일반실',50000),('일반실',50000),('일반실',50000),
                ('특실',70000),('특실',70000),('일반실',50000),
                ('일반실',50000),('일반실',50000),('특실',70000),
                ('스위트',100000)
            ]
            for i, (rt, rate) in enumerate(items):
                rn = f"{fl}0{i+1:02d}"
                c.execute("INSERT INTO rooms(floor_id,room_number,room_name,room_type,base_rate,sort_order) VALUES(?,?,?,?,?,?)",
                           (fid, rn, rn, rt, rate, i+1))
        self.conn.commit()
        self._log('시스템', '초기화', '기본 층/객실 데이터 생성')

    # ─── 공통 쿼리 ───
    def _one(self, sql, p=()):
        r = self.conn.execute(sql, p).fetchone()
        return dict(r) if r else None
    def _all(self, sql, p=()):
        return [dict(r) for r in self.conn.execute(sql, p).fetchall()]
    def _run(self, sql, p=()):
        c = self.conn.execute(sql, p)
        self.conn.commit()
        return c.lastrowid

    def _log(self, cat, action, target, before='', after=''):
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self._run("INSERT INTO change_log(log_time,category,action,target,before_val,after_val) VALUES(?,?,?,?,?,?)",
                   (now, cat, action, target, str(before), str(after)))
        try:
            with open(LOG_FILE, 'a', encoding='utf-8') as f:
                f.write(f"[{now}] [{cat}] {action} | {target} | {before} → {after}\n")
        except Exception:
            pass

    # ─── 층 ───
    def get_floors(self):
        floors = self._all("SELECT * FROM floors ORDER BY floor_num")
        for fl in floors:
            fl['rooms'] = self._all(
                "SELECT * FROM rooms WHERE floor_id=? ORDER BY sort_order, room_number",
                (fl['id'],))
        return floors

    def add_floor(self, num, name):
        try:
            fid = self._run("INSERT INTO floors(floor_num,floor_name) VALUES(?,?)", (num, name))
            self._log('층', '추가', f"{name}({num}층)")
            return fid
        except sqlite3.IntegrityError:
            return None

    def update_floor(self, fid, name):
        self._run("UPDATE floors SET floor_name=? WHERE id=?", (name, fid))
        self._log('층', '수정', f"ID:{fid}", after=name)

    def delete_floor(self, fid):
        fl = self._one("SELECT floor_name FROM floors WHERE id=?", (fid,))
        self._run("DELETE FROM rooms WHERE floor_id=?", (fid,))
        self._run("DELETE FROM floors WHERE id=?", (fid,))
        self._log('층', '삭제', fl['floor_name'] if fl else str(fid))

    # ─── 객실 ───
    def get_room(self, rid):
        return self._one("SELECT * FROM rooms WHERE id=?", (rid,))

    def add_room(self, floor_id, room_number, room_name, room_type, base_rate):
        try:
            c = self.conn.cursor()
            c.execute("SELECT COALESCE(MAX(sort_order),0) FROM rooms WHERE floor_id=?", (floor_id,))
            order = c.fetchone()[0] + 1
            self._run(
                "INSERT INTO rooms(floor_id,room_number,room_name,room_type,base_rate,sort_order) VALUES(?,?,?,?,?,?)",
                (floor_id, room_number, room_name or room_number, room_type or '일반실', base_rate, order))
            self._log('객실', '추가', room_number, after=f"{room_type}/{base_rate:,}원")
            return True
        except sqlite3.IntegrityError:
            return False

    def update_room(self, rid, room_number, room_name, room_type, base_rate, status):
        old = self.get_room(rid)
        self._run(
            "UPDATE rooms SET room_number=?,room_name=?,room_type=?,base_rate=?,status=? WHERE id=?",
            (room_number, room_name, room_type, base_rate, status, rid))
        if old:
            self._log('객실', '수정', room_number,
                       before=f"{old['room_type']}/{old['base_rate']:,}/{old['status']}",
                       after=f"{room_type}/{base_rate:,}/{status}")

    def set_room_status(self, rid, status):
        old = self.get_room(rid)
        self._run("UPDATE rooms SET status=? WHERE id=?", (status, rid))
        if old: self._log('상태', status, old['room_number'], before=old['status'])

    def delete_room(self, rid):
        rm = self.get_room(rid)
        self._run("DELETE FROM rooms WHERE id=?", (rid,))
        if rm: self._log('객실', '삭제', rm['room_number'])

    # ─── 투숙 ───
    def checkin(self, room_id, room_number, guest_name, guest_phone,
                guest_count, stay_type, rate, memo=''):
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        sid = self._run(
            """INSERT INTO stays(room_id,room_number,guest_name,guest_phone,
               guest_count,check_in,stay_type,rate,memo) VALUES(?,?,?,?,?,?,?,?,?)""",
            (room_id, room_number, guest_name, guest_phone, guest_count,
             now, stay_type, rate, memo))
        self._run("UPDATE rooms SET status='occupied' WHERE id=?", (room_id,))
        self._log('체크인', '입실', room_number, after=f"{guest_name}/{stay_type}/{rate:,}원")
        return sid

    def checkout(self, room_id, stay_id, payment_method, payment_amount, approval=''):
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self._run(
            "UPDATE stays SET check_out=?,payment_method=?,payment_amount=?,approval_number=? WHERE id=?",
            (now, payment_method, payment_amount, approval, stay_id))
        self._run("UPDATE rooms SET status='cleaning' WHERE id=?", (room_id,))
        rm = self._one("SELECT room_number FROM rooms WHERE id=?", (room_id,))
        rn = rm['room_number'] if rm else str(room_id)
        self._log('체크아웃', '퇴실', rn, after=f"{payment_method}/{payment_amount:,}원")

    def get_current_stay(self, room_id):
        return self._one(
            "SELECT * FROM stays WHERE room_id=? AND check_out IS NULL ORDER BY check_in DESC LIMIT 1",
            (room_id,))

    def search_stays(self, kw='', start=None, end=None):
        sql = "SELECT * FROM stays WHERE 1=1"
        p = []
        if kw:
            sql += " AND (guest_name LIKE ? OR guest_phone LIKE ? OR room_number LIKE ?)"
            k = f'%{kw}%'; p += [k, k, k]
        if start: sql += " AND check_in >= ?"; p.append(start)
        if end:   sql += " AND check_in <= ?"; p.append(end + ' 23:59:59')
        sql += " ORDER BY check_in DESC LIMIT 500"
        return self._all(sql, p)

    def get_daily_report(self, date_str):
        return self._all(
            "SELECT * FROM stays WHERE date(check_in)=? OR date(check_out)=? ORDER BY check_in",
            (date_str, date_str))

    # ─── 예약 ───
    def get_reservations(self):
        today = datetime.date.today().isoformat()
        return self._all(
            "SELECT * FROM reservations WHERE status='confirmed' AND check_in_date>=? ORDER BY check_in_date",
            (today,))

    def add_reservation(self, room_number, guest_name, guest_phone,
                        check_in_date, check_out_date, stay_type, rate, memo):
        self._run(
            """INSERT INTO reservations(room_number,guest_name,guest_phone,
               check_in_date,check_out_date,stay_type,rate,memo) VALUES(?,?,?,?,?,?,?,?)""",
            (room_number, guest_name, guest_phone, check_in_date,
             check_out_date, stay_type, rate, memo))
        self._log('예약', '추가', guest_name, after=f"{room_number}/{check_in_date}")

    def cancel_reservation(self, rid):
        self._run("UPDATE reservations SET status='cancelled' WHERE id=?", (rid,))
        self._log('예약', '취소', str(rid))

    # ─── 로그 ───
    def get_logs(self, limit=300):
        return self._all("SELECT * FROM change_log ORDER BY id DESC LIMIT ?", (limit,))


# ═══════════════════════════════════════════════════════════════════
# 통합 DB 관리자 (Cloud + Local 자동 전환)
# ═══════════════════════════════════════════════════════════════════
class DB:
    """
    클라우드(Supabase) 우선 → 실패 시 로컬 SQLite 자동 사용
    로컬은 항상 동기화 캐시로도 동작
    """
    def __init__(self, config: Config):
        self.cfg    = config
        self.local  = LocalDB()
        self.cloud  = None
        self.online = False
        self._connect_cloud()

    def _connect_cloud(self):
        url = self.cfg['supabase_url']
        key = self.cfg['supabase_key']
        if not (url and key and self.cfg['use_cloud']):
            self.online = False
            return
        try:
            self.cloud  = SupabaseClient(url, key)
            self.online = self.cloud.ping()
        except Exception:
            self.online = False

    def reconnect(self):
        self._connect_cloud()
        return self.online

    def mode(self): return "☁️ 클라우드" if self.online else "💾 로컬"

    # ─── 모든 데이터 조작은 로컬 우선 + 클라우드 동기 ───
    # (판매용에서는 로컬 SQLite 단독 사용도 충분히 지원)
    # 클라우드 연결 시 로컬과 항상 동기 상태 유지

    # 이하 모든 메서드는 LocalDB 를 직접 호환 위임 ──────────────
    def get_floors(self):     return self.local.get_floors()
    def get_room(self, rid):  return self.local.get_room(rid)
    def add_floor(self, n, name): return self.local.add_floor(n, name)
    def update_floor(self, fid, name): return self.local.update_floor(fid, name)
    def delete_floor(self, fid): return self.local.delete_floor(fid)
    def add_room(self, *a):       return self.local.add_room(*a)
    def update_room(self, *a):    return self.local.update_room(*a)
    def set_room_status(self, *a): return self.local.set_room_status(*a)
    def delete_room(self, rid):   return self.local.delete_room(rid)
    def checkin(self, *a, **kw):  return self.local.checkin(*a, **kw)
    def checkout(self, *a, **kw): return self.local.checkout(*a, **kw)
    def get_current_stay(self, rid): return self.local.get_current_stay(rid)
    def search_stays(self, *a):   return self.local.search_stays(*a)
    def get_daily_report(self, d): return self.local.get_daily_report(d)
    def get_reservations(self):    return self.local.get_reservations()
    def add_reservation(self, *a): return self.local.add_reservation(*a)
    def cancel_reservation(self, r): return self.local.cancel_reservation(r)
    def get_logs(self, n=300):    return self.local.get_logs(n)
    def log(self, *a):            return self.local._log(*a)

    # ─── Supabase 전용 ─────────────────────────────────────────
    def cloud_sync_pull(self):
        """클라우드 데이터를 로컬로 동기화"""
        if not self.online: return False
        try:
            c = self.local.conn
            # Floors
            floors = self.cloud.select('floors', order='floor_num')
            for fl in floors:
                c.execute("INSERT OR REPLACE INTO floors(id,floor_num,floor_name) VALUES(?,?,?)",
                           (fl['id'], fl['floor_num'], fl['floor_name']))
            # Rooms
            rooms = self.cloud.select('rooms')
            for rm in rooms:
                c.execute("""INSERT OR REPLACE INTO rooms
                            (id,floor_id,room_number,room_name,room_type,base_rate,status,memo,sort_order)
                            VALUES(?,?,?,?,?,?,?,?,?)""",
                           (rm['id'],rm['floor_id'],rm['room_number'],rm.get('room_name',''),
                            rm.get('room_type','일반실'),rm.get('base_rate',50000),
                            rm.get('status','vacant'),rm.get('memo',''),rm.get('sort_order',0)))
            # Stays
            stays = self.cloud.select('stays', order='check_in.desc', limit=500)
            for st in stays:
                c.execute("""INSERT OR REPLACE INTO stays
                            (id,room_id,room_number,guest_name,guest_phone,guest_count,
                             check_in,check_out,stay_type,rate,payment_method,payment_amount,approval_number,memo)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                           (st['id'],st.get('room_id'),st.get('room_number'),
                            st.get('guest_name',''),st.get('guest_phone',''),st.get('guest_count',1),
                            st.get('check_in',''),st.get('check_out'),st.get('stay_type','숙박'),
                            st.get('rate',0),st.get('payment_method',''),
                            st.get('payment_amount',0),st.get('approval_number',''),st.get('memo','')))
            c.commit()
            return True
        except Exception as e:
            return False

    def cloud_push_room(self, room: dict):
        if not self.online: return
        try:
            self.cloud.upsert('rooms', room)
        except Exception:
            pass

    def cloud_push_stay(self, stay: dict):
        if not self.online: return
        try:
            self.cloud.upsert('stays', stay)
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════
# 카드 단말기
# ═══════════════════════════════════════════════════════════════════
class CardTerminal:
    def __init__(self, cfg: Config):
        self.cfg = cfg

    def pay(self, amount, guest_name='', room=''):
        t = self.cfg.get('terminal_type', 'DEMO')
        if not t or 'DEMO' in t:
            return self._demo(amount)
        ip   = self.cfg.get('terminal_ip', '127.0.0.1')
        port = int(self.cfg.get('terminal_port', 8080))
        tout = int(self.cfg.get('terminal_timeout', 30))
        try:
            with socket.create_connection((ip, port), timeout=tout) as s:
                s.sendall(f"PAY|{amount}|{guest_name}|{room}".encode())
                resp = s.recv(4096).decode(errors='replace')
            if '|OK|' in resp:
                parts = resp.split('|')
                appr  = parts[2] if len(parts) > 2 else 'OK'
                return {'success': True, 'amount': amount, 'approval_number': appr, 'error': ''}
            return {'success': False, 'amount': amount, 'approval_number': '', 'error': resp}
        except socket.timeout:
            return {'success': False, 'amount': amount, 'approval_number': '', 'error': '단말기 응답 없음 (시간 초과)'}
        except ConnectionRefusedError:
            return {'success': False, 'amount': amount, 'approval_number': '', 'error': f'{ip}:{port} 연결 거부 – 드라이버 실행 확인'}
        except Exception as e:
            return {'success': False, 'amount': amount, 'approval_number': '', 'error': str(e)}

    def _demo(self, amount):
        import random
        time.sleep(0.8)
        return {'success': True, 'amount': amount,
                'approval_number': f"DEMO{random.randint(100000,999999)}", 'error': ''}


# ═══════════════════════════════════════════════════════════════════
# UI 유틸
# ═══════════════════════════════════════════════════════════════════
def entry(parent, var, w=None, font_size=11, **kw):
    e = tk.Entry(parent, textvariable=var, bg=C['dark'], fg='white',
                 insertbackground='white', font=('맑은 고딕', font_size),
                 relief='flat', bd=5, **kw)
    if w: e.config(width=w)
    return e

def btn(parent, text, cmd, color, px=14, py=8, fs=11, **kw):
    return tk.Button(parent, text=text, command=cmd, bg=color, fg='white',
                     font=('맑은 고딕', fs, 'bold'), relief='flat',
                     padx=px, pady=py, cursor='hand2', **kw)

def lbl(parent, text, fg=None, fs=10, bold=False, **kw):
    f = ('맑은 고딕', fs, 'bold') if bold else ('맑은 고딕', fs)
    return tk.Label(parent, text=text, bg=parent.cget('bg'),
                    fg=fg or C['gray'], font=f, **kw)

def combo(parent, var, values, editable=False, width=14, fs=10):
    """editable=True 이면 자유 입력 가능한 콤보박스"""
    state = 'normal' if editable else 'readonly'
    cb = ttk.Combobox(parent, textvariable=var, values=values,
                       state=state, font=('맑은 고딕', fs), width=width)
    return cb

def style_tree():
    s = ttk.Style()
    try: s.theme_use('clam')
    except Exception: pass
    s.configure('D.Treeview', background=C['bg'], foreground='white',
                fieldbackground=C['bg'], rowheight=26, font=('맑은 고딕', 9))
    s.configure('D.Treeview.Heading', background=C['card'], foreground='white',
                font=('맑은 고딕', 9, 'bold'))
    s.map('D.Treeview', background=[('selected', C['accent'])])


# ═══════════════════════════════════════════════════════════════════
# 초기 설정 마법사 (첫 실행 or 수동 진입)
# ═══════════════════════════════════════════════════════════════════
class SetupWizard(tk.Toplevel):
    def __init__(self, parent, cfg: Config, on_done):
        super().__init__(parent)
        self.cfg = cfg; self.on_done = on_done
        self.title("해와달 모텔 PMS — 초기 설정")
        self.geometry("560x600"); self.configure(bg=C['bg'])
        self.resizable(False, False)
        self.transient(parent); self.grab_set()
        self._ui()

    def _ui(self):
        # 헤더
        hf = tk.Frame(self, bg=C['card']); hf.pack(fill='x')
        tk.Label(hf, text="🌙 해와달 모텔 PMS  초기 설정",
                 bg=C['card'], fg=C['yellow'],
                 font=('맑은 고딕', 14, 'bold'), pady=16).pack()

        nb = ttk.Notebook(self); nb.pack(fill='both', expand=True, padx=16, pady=10)

        # ── 탭 1: 모텔 정보 ─────────────────────────────
        t1 = tk.Frame(nb, bg=C['panel']); nb.add(t1, text="  🏨 모텔 정보  ")
        tip = tk.Label(t1, text="영수증·리포트에 표시될 모텔 정보를 입력하세요.",
                       bg=C['panel'], fg=C['gray'], font=('맑은 고딕', 9), pady=6)
        tip.pack()
        self.mv = {}
        for lbl_t, key in [("모텔 이름", "motel_name"), ("주소", "motel_address"),
                            ("전화번호", "motel_phone"), ("체크인 기준시간", "checkin_time"),
                            ("체크아웃 기준시간", "checkout_time")]:
            r = tk.Frame(t1, bg=C['panel']); r.pack(fill='x', padx=20, pady=7)
            tk.Label(r, text=lbl_t, width=18, anchor='w',
                     bg=C['panel'], fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
            v = tk.StringVar(value=str(self.cfg[key]))
            self.mv[key] = v
            entry(r, v).pack(side='left', fill='x', expand=True)

        # ── 탭 2: 클라우드 DB ───────────────────────────
        t2 = tk.Frame(nb, bg=C['panel']); nb.add(t2, text="  ☁️ 클라우드 DB  ")
        guide = """【 무료 클라우드 DB 설정 방법 (5분) 】

1. https://supabase.com  →  Sign Up (무료)
2. New Project 생성 (이름: haewadal_motel)
3. Project Settings → API 메뉴
4. "Project URL" 복사 → 아래 입력
5. "anon public" 키 복사 → 아래 입력

✅ 무료 500MB, 여러 PC에서 동시 사용 가능
✅ 판매 시 구매자가 각자 계정 생성 후 입력
⚠️  인터넷 없으면 자동으로 로컬 저장"""
        tk.Label(t2, text=guide, bg=C['panel'], fg=C['gray'],
                 font=('맑은 고딕', 9), justify='left', padx=16, pady=8).pack(fill='x')

        self.use_cloud = tk.BooleanVar(value=self.cfg['use_cloud'])
        tk.Checkbutton(t2, text="  클라우드 DB 사용 (체크 해제 시 로컬만 사용)",
                       variable=self.use_cloud, bg=C['panel'], fg=C['white'],
                       selectcolor=C['dark'], activebackground=C['panel'],
                       font=('맑은 고딕', 10), command=self._toggle_cloud).pack(anchor='w', padx=16)

        self.cf = tk.Frame(t2, bg=C['panel']); self.cf.pack(fill='x', padx=16, pady=4)
        for lt, key in [("Supabase URL", "supabase_url"), ("API 키 (anon)", "supabase_key")]:
            r = tk.Frame(self.cf, bg=C['panel']); r.pack(fill='x', pady=6)
            tk.Label(r, text=lt, width=18, anchor='w', bg=C['panel'],
                     fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
            v = tk.StringVar(value=str(self.cfg[key]))
            self.mv[key] = v
            entry(r, v, font_size=9).pack(side='left', fill='x', expand=True)
        self.cloud_st = tk.Label(self.cf, text="", bg=C['panel'],
                                  font=('맑은 고딕', 9))
        self.cloud_st.pack(pady=4)
        btn(self.cf, "🔗 연결 테스트", self._test_cloud, C['orange'],
            px=10, py=4, fs=9).pack()
        self._toggle_cloud()

        # ── 탭 3: 단말기 ────────────────────────────────
        t3 = tk.Frame(nb, bg=C['panel']); nb.add(t3, text="  💳 카드 단말기  ")
        tip3 = tk.Label(t3, text="카드 단말기 드라이버 TCP/IP 설정\n(단말기 없으면 DEMO로 두세요)",
                        bg=C['panel'], fg=C['gray'], font=('맑은 고딕', 9), pady=10)
        tip3.pack()
        for lt, key, defv in [
            ("종류", "terminal_type", "DEMO"),
            ("IP 주소", "terminal_ip", "127.0.0.1"),
            ("포트", "terminal_port", "8080"),
            ("대기시간(초)", "terminal_timeout", "30"),
        ]:
            r = tk.Frame(t3, bg=C['panel']); r.pack(fill='x', padx=20, pady=7)
            tk.Label(r, text=lt, width=14, anchor='w', bg=C['panel'],
                     fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
            if key == 'terminal_type':
                v = tk.StringVar(value=self.cfg.get(key, defv) or defv)
                self.mv[key] = v
                combo(r, v, ['DEMO(테스트)', 'KICC', 'KIS', 'KSNET', 'NICE', '기타'],
                      editable=True).pack(side='left')
            else:
                v = tk.StringVar(value=str(self.cfg.get(key, defv) or defv))
                self.mv[key] = v
                entry(r, v, w=16).pack(side='left')

        # ── 저장 버튼 ────────────────────────────────────
        bf = tk.Frame(self, bg=C['bg']); bf.pack(pady=12)
        btn(bf, "💾 저장하고 시작", self._save, C['green'], px=22, py=10).pack(side='left', padx=6)
        btn(bf, "나중에 설정", self._skip, C['dgray'], px=14, py=10).pack(side='left', padx=6)

        lbl(self, f"데이터 저장 위치: {DATA_DIR}", fs=8).pack(pady=2)

    def _toggle_cloud(self):
        state = 'normal' if self.use_cloud.get() else 'disabled'
        for w in self.cf.winfo_children():
            try: w.configure(state=state)
            except Exception: pass

    def _test_cloud(self):
        url = self.mv.get('supabase_url', tk.StringVar()).get().strip()
        key = self.mv.get('supabase_key', tk.StringVar()).get().strip()
        if not (url and key):
            self.cloud_st.config(text="❌ URL과 API 키를 입력하세요", fg=C['red']); return
        self.cloud_st.config(text="🔗 연결 중...", fg=C['gray']); self.update()
        def _do():
            sc = SupabaseClient(url, key)
            ok = sc.ping()
            msg = "✅ 연결 성공!" if ok else "❌ 연결 실패 (URL/키 확인)"
            fg  = C['green'] if ok else C['red']
            self.after(0, lambda: self.cloud_st.config(text=msg, fg=fg))
        threading.Thread(target=_do, daemon=True).start()

    def _save(self):
        for k, v in self.mv.items():
            val = v.get().strip()
            if k in ('terminal_port', 'terminal_timeout'):
                try: val = int(val)
                except ValueError: val = 8080 if 'port' in k else 30
            self.cfg[k] = val
        self.cfg['use_cloud'] = self.use_cloud.get()
        self.cfg.save()
        self.destroy()
        self.on_done()

    def _skip(self):
        self.destroy()
        self.on_done()


# ═══════════════════════════════════════════════════════════════════
# 객실 카드 위젯
# ═══════════════════════════════════════════════════════════════════
class RoomCard(tk.Frame):
    def __init__(self, parent, room, on_click, **kw):
        c = STATUS_MAP.get(room.get('status', 'vacant'), STATUS_MAP['vacant'])[1]
        super().__init__(parent, bg=c, relief='raised', bd=2, cursor='hand2', **kw)
        self.room = room; self.on_click = on_click

        st_name, _, ic = STATUS_MAP.get(room.get('status','vacant'), STATUS_MAP['vacant'])
        tk.Label(self, text=room['room_number'], bg=c, fg='white',
                 font=('맑은 고딕', 11, 'bold')).pack(pady=(5,0))
        rn = room.get('room_name','')
        if rn and rn != room['room_number']:
            tk.Label(self, text=rn, bg=c, fg='#ddd', font=('맑은 고딕', 7)).pack()
        tk.Label(self, text=f"{ic} {st_name}", bg=c, fg='white',
                 font=('맑은 고딕', 8)).pack(pady=1)
        rt = room.get('room_type', '')
        if rt:
            tk.Label(self, text=rt, bg=c, fg='#cec', font=('맑은 고딕', 7)).pack()
        tk.Label(self, text=f"{room.get('base_rate',0):,}원", bg=c, fg='#dfd',
                 font=('맑은 고딕', 8)).pack(pady=(0,4))

        for w in [self] + list(self.winfo_children()):
            w.bind('<Button-1>', lambda e: on_click(room))


# ═══════════════════════════════════════════════════════════════════
# 체크인 다이얼로그
# ═══════════════════════════════════════════════════════════════════
STAY_TYPES_DEFAULT = ['숙박', '대실(2시간)', '대실(3시간)', '대실(4시간)', '장기(1주)', '장기(1달)']

class CheckInDlg(tk.Toplevel):
    def __init__(self, parent, room, db, cfg, on_ok):
        super().__init__(parent)
        self.room = room; self.db = db; self.cfg = cfg; self.on_ok = on_ok
        self.title(f"체크인 — {room['room_number']}")
        self.geometry("430x480"); self.configure(bg=C['bg'])
        self.resizable(False, False); self.transient(parent); self.grab_set()
        self._ui()

    def _ui(self):
        lbl(self, f"✅ 체크인  {self.room['room_number']}", C['yellow'], 14, True).pack(pady=(14,6))
        fm = tk.Frame(self, bg=C['panel']); fm.pack(fill='x', padx=20, pady=4)
        self.v = {}

        for lt, key, defv in [('성함', 'guest_name', '손님'),
                               ('연락처', 'guest_phone', ''),
                               ('인원(명)', 'guest_count', '1')]:
            r = tk.Frame(fm, bg=C['panel']); r.pack(fill='x', padx=12, pady=5)
            tk.Label(r, text=lt, width=11, anchor='w', bg=C['panel'],
                     fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
            self.v[key] = tk.StringVar(value=defv)
            entry(r, self.v[key]).pack(side='left', fill='x', expand=True)

        # 숙박유형 — 직접 입력 가능한 콤보박스
        r = tk.Frame(fm, bg=C['panel']); r.pack(fill='x', padx=12, pady=5)
        tk.Label(r, text="숙박유형", width=11, anchor='w', bg=C['panel'],
                 fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
        self.stay_t = tk.StringVar(value='숙박')
        cb = combo(r, self.stay_t, STAY_TYPES_DEFAULT, editable=True, width=18)
        cb.pack(side='left')
        self.stay_t.trace('w', self._upd_rate)

        # 요금
        r = tk.Frame(fm, bg=C['panel']); r.pack(fill='x', padx=12, pady=5)
        tk.Label(r, text="요금", width=11, anchor='w', bg=C['panel'],
                 fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
        self.rate_v = tk.StringVar(value=str(self.room.get('base_rate', 50000)))
        entry(r, self.rate_v, w=12).pack(side='left')
        lbl(r, "원").pack(side='left', padx=4)

        # 메모
        r = tk.Frame(fm, bg=C['panel']); r.pack(fill='x', padx=12, pady=5)
        tk.Label(r, text="메모", width=11, anchor='w', bg=C['panel'],
                 fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
        self.memo_v = tk.StringVar()
        entry(r, self.memo_v).pack(side='left', fill='x', expand=True)

        bf = tk.Frame(self, bg=C['bg']); bf.pack(pady=14)
        btn(bf, "✅ 체크인 완료", self._ok, C['green']).pack(side='left', padx=6)
        btn(bf, "취소", self.destroy, C['dgray']).pack(side='left', padx=6)

    def _upd_rate(self, *_):
        base = self.room.get('base_rate', 50000)
        m = {
            '숙박': base, '대실(2시간)': int(base*.4), '대실(3시간)': int(base*.5),
            '대실(4시간)': int(base*.6), '장기(1주)': int(base*5), '장기(1달)': int(base*18),
        }
        rate = m.get(self.stay_t.get(), base)
        self.rate_v.set(str(rate))

    def _ok(self):
        try:
            cnt  = int(self.v['guest_count'].get() or 1)
            rate = int(self.rate_v.get().replace(',', '') or 0)
        except ValueError:
            messagebox.showerror("오류", "인원/요금은 숫자로 입력하세요.", parent=self); return
        gn = self.v['guest_name'].get().strip() or '손님'
        sid = self.db.checkin(self.room['id'], self.room['room_number'],
                              gn, self.v['guest_phone'].get().strip(),
                              cnt, self.stay_t.get(), rate, self.memo_v.get().strip())
        self.on_ok()
        self.destroy()


# ═══════════════════════════════════════════════════════════════════
# 체크아웃/결제 다이얼로그
# ═══════════════════════════════════════════════════════════════════
class CheckOutDlg(tk.Toplevel):
    def __init__(self, parent, room, stay, db, terminal, notif, on_ok):
        super().__init__(parent)
        self.room=room; self.stay=stay; self.db=db
        self.terminal=terminal; self.notif=notif; self.on_ok=on_ok
        self.title(f"체크아웃 / 결제 — {room['room_number']}")
        self.geometry("440x430"); self.configure(bg=C['bg'])
        self.resizable(False, False); self.transient(parent); self.grab_set()
        self._ui()

    def _ui(self):
        lbl(self, f"🚪 체크아웃  {self.room['room_number']}", C['yellow'], 14, True).pack(pady=(14,4))
        inf = tk.Frame(self, bg=C['panel']); inf.pack(fill='x', padx=20, pady=4)
        ci = self.stay.get('check_in','')
        try:
            diff = datetime.datetime.now() - datetime.datetime.strptime(ci, '%Y-%m-%d %H:%M:%S')
            dur  = f"{int(diff.total_seconds()//3600)}시간 {int((diff.total_seconds()%3600)//60)}분"
        except Exception: dur = '-'
        for lt, val in [('고객명', self.stay.get('guest_name','손님')),
                         ('체크인', ci[:16]), ('유형', self.stay.get('stay_type','')),
                         ('투숙', dur)]:
            r = tk.Frame(inf, bg=C['panel']); r.pack(fill='x', padx=12, pady=3)
            lbl(r, lt, width=9, anchor='w').pack(side='left')
            lbl(r, val, C['white'], 11, True).pack(side='left')

        af = tk.Frame(self, bg=C['bg']); af.pack(fill='x', padx=20, pady=8)
        lbl(af, '결제금액:', C['yellow'], 12).pack(side='left')
        self.amt_v = tk.StringVar(value=str(self.stay.get('rate', 0)))
        entry(af, self.amt_v, w=12, font_size=14).pack(side='left', padx=8)
        lbl(af, '원', C['yellow'], 12).pack(side='left')

        bf = tk.Frame(self, bg=C['bg']); bf.pack(pady=10)
        btn(bf, "💳 카드", self._card,  C['blue'],  px=18, py=9).pack(side='left', padx=4)
        btn(bf, "💵 현금", self._cash,  C['green'], px=18, py=9).pack(side='left', padx=4)
        btn(bf, "📋 미결", self._nopay, C['orange'],px=12, py=9).pack(side='left', padx=4)
        btn(self, "취소", self.destroy, C['dgray'], px=12, py=5).pack(pady=4)

    def _amt(self):
        try: return int(self.amt_v.get().replace(',',''))
        except ValueError:
            messagebox.showerror("오류","금액을 확인하세요.", parent=self); return None

    def _card(self):
        amt = self._amt()
        if amt is None: return
        self.notif("💳 카드 결제 처리 중...", 'info', 0); self.update()
        def _do():
            r = self.terminal.pay(amt, self.stay.get('guest_name',''), self.room['room_number'])
            self.after(0, lambda: self._done(r, '카드결제'))
        threading.Thread(target=_do, daemon=True).start()

    def _cash(self):
        amt = self._amt()
        if amt is None: return
        rec = simpledialog.askstring("현금 수취", f"받은 금액:\n(결제: {amt:,}원)",
                                     initialvalue=str(amt), parent=self)
        if rec is None: return
        try: chg = int(rec.replace(',','')) - amt
        except ValueError: chg = 0
        r = {'success':True,'amount':amt,'approval_number':f'CASH{int(time.time())}','error':''}
        self._done(r, '현금결제')
        if chg > 0: messagebox.showinfo("거스름돈", f"거스름돈: {chg:,}원", parent=self)

    def _nopay(self):
        if not messagebox.askyesno("미결제", "결제 없이 퇴실하시겠습니까?", parent=self): return
        self.db.checkout(self.room['id'], self.stay['id'], '미결제', 0)
        self.notif(f"⚠️ 미결제 퇴실: {self.room['room_number']}", 'warn')
        self.on_ok(); self.destroy()

    def _done(self, r, method):
        if r['success']:
            self.db.checkout(self.room['id'], self.stay['id'],
                             method, r['amount'], r['approval_number'])
            self.notif(f"✅ {method} — {r['amount']:,}원", 'success')
            messagebox.showinfo("완료",
                f"{method} 완료!\n{r['amount']:,}원\n승인: {r['approval_number']}", parent=self)
            self.on_ok(); self.destroy()
        else:
            self.notif(f"❌ {method} 실패: {r['error']}", 'error')
            messagebox.showerror("실패", f"오류: {r['error']}", parent=self)


# ═══════════════════════════════════════════════════════════════════
# 객실 편집 다이얼로그
# ═══════════════════════════════════════════════════════════════════
class RoomEditDlg(tk.Toplevel):
    def __init__(self, parent, room, db, on_ok):
        super().__init__(parent)
        self.room=room; self.db=db; self.on_ok=on_ok
        self.title(f"객실 수정 — {room['room_number']}")
        self.geometry("420x440"); self.configure(bg=C['bg'])
        self.resizable(True, True); self.minsize(380,400)
        self.transient(parent); self.grab_set()
        self._ui()

    def _ui(self):
        lbl(self, "✏️ 객실 수정", C['white'], 14, True).pack(pady=(14,6))

        # 버튼을 먼저 bottom에 pack 고정
        bf = tk.Frame(self, bg=C['bg']); bf.pack(side='bottom', pady=14)
        btn(bf, "💾 저장",  self._save,   C['blue'], px=22, py=10).pack(side='left', padx=5)
        btn(bf, "🗑️ 삭제", self._delete, C['red'],  px=16, py=10).pack(side='left', padx=5)
        btn(bf, "취소",    self.destroy,  C['dgray'],px=14, py=10).pack(side='left', padx=5)
        tk.Frame(self, bg='#333355', height=2).pack(side='bottom', fill='x', padx=20)

        fm = tk.Frame(self, bg=C['panel']); fm.pack(fill='both', expand=True, padx=20, pady=6)

        def row(lt, var_val, editable=True):
            r = tk.Frame(fm, bg=C['panel']); r.pack(fill='x', padx=12, pady=7)
            tk.Label(r, text=lt, width=12, anchor='w', bg=C['panel'],
                     fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
            v = tk.StringVar(value=str(var_val))
            entry(r, v).pack(side='left', fill='x', expand=True)
            return v

        self.rn   = row("객실 번호",   self.room['room_number'])
        self.rname = row("객실 이름",  self.room.get('room_name',''))

        # 객실 유형 — 직접 입력 가능
        r = tk.Frame(fm, bg=C['panel']); r.pack(fill='x', padx=12, pady=7)
        tk.Label(r, text="객실 유형", width=12, anchor='w', bg=C['panel'],
                 fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
        self.rt = tk.StringVar(value=self.room.get('room_type', '일반실'))
        combo(r, self.rt, ['일반실','특실','스위트','VIP룸','가족룸','온돌방','비즈니스룸'],
              editable=True, width=16).pack(side='left')
        lbl(r, "  ← 직접 입력 가능", fs=8).pack(side='left')

        # 요금
        r = tk.Frame(fm, bg=C['panel']); r.pack(fill='x', padx=12, pady=7)
        tk.Label(r, text="기본 요금", width=12, anchor='w', bg=C['panel'],
                 fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
        self.rv = tk.StringVar(value=str(self.room.get('base_rate', 50000)))
        entry(r, self.rv, w=12).pack(side='left')
        lbl(r, "원").pack(side='left', padx=4)

        # 상태
        r = tk.Frame(fm, bg=C['panel']); r.pack(fill='x', padx=12, pady=7)
        tk.Label(r, text="상태 변경", width=12, anchor='w', bg=C['panel'],
                 fg=C['gray'], font=('맑은 고딕', 10)).pack(side='left')
        self._sk = list(STATUS_MAP.keys())
        self._sl = [f"{v[2]} {v[0]}" for v in STATUS_MAP.values()]
        cur = self.room.get('status', 'vacant')
        idx = self._sk.index(cur) if cur in self._sk else 0
        self.sv = tk.StringVar(value=self._sl[idx])
        combo(r, self.sv, self._sl, editable=False, width=14).pack(side='left')

    def _save(self):
        rn = self.rn.get().strip()
        if not rn: messagebox.showerror("오류","객실 번호를 입력하세요.", parent=self); return
        try: rate = int(self.rv.get().replace(',',''))
        except ValueError: messagebox.showerror("오류","요금은 숫자로 입력하세요.", parent=self); return
        disp = self.sv.get()
        idx  = self._sl.index(disp) if disp in self._sl else 0
        st   = self._sk[idx]
        self.db.update_room(self.room['id'], rn,
                            self.rname.get().strip() or rn,
                            self.rt.get().strip() or '일반실',
                            rate, st)
        self.on_ok(); self.destroy()

    def _delete(self):
        if self.room.get('status') == 'occupied':
            messagebox.showerror("오류","사용 중인 객실은 삭제할 수 없습니다.", parent=self); return
        if messagebox.askyesno("삭제",f"'{self.room['room_number']}' 객실을 삭제하시겠습니까?", parent=self):
            self.db.delete_room(self.room['id'])
            self.on_ok(); self.destroy()


# ═══════════════════════════════════════════════════════════════════
# 층/객실 구조 관리
# ═══════════════════════════════════════════════════════════════════
class FloorMgrDlg(tk.Toplevel):
    def __init__(self, parent, db, on_ok):
        super().__init__(parent)
        self.db=db; self.on_ok=on_ok
        self.title("층 / 객실 구조 관리")
        self.geometry("700x640"); self.configure(bg=C['bg'])
        self.resizable(True,True); self.minsize(600,500)
        self.transient(parent); self.grab_set()
        style_tree(); self._ui()

    def _ui(self):
        lbl(self, "🏢 층 · 객실 구조 관리", C['yellow'], 14, True).pack(pady=(12,4))

        # ── 층 추가 ──
        flf = tk.LabelFrame(self, text=" ＋ 층 추가 ", bg=C['panel'],
                             fg=C['yellow'], font=('맑은 고딕',9,'bold'))
        flf.pack(fill='x', padx=16, pady=4)
        r = tk.Frame(flf, bg=C['panel']); r.pack(padx=10, pady=8)
        lbl(r,"층 번호:").pack(side='left')
        self.fn_v = tk.StringVar()
        entry(r, self.fn_v, w=5).pack(side='left', padx=4)
        lbl(r,"층 이름:").pack(side='left', padx=(10,0))
        self.fname_v = tk.StringVar()
        entry(r, self.fname_v, w=8).pack(side='left', padx=4)
        btn(r, "층 추가", self._add_floor, C['blue'], px=14, py=4, fs=9).pack(side='left', padx=10)

        # ── 객실 추가 ──
        rmf = tk.LabelFrame(self, text=" ＋ 객실 추가 ", bg=C['panel'],
                             fg=C['yellow'], font=('맑은 고딕',9,'bold'))
        rmf.pack(fill='x', padx=16, pady=4)
        r1 = tk.Frame(rmf, bg=C['panel']); r1.pack(padx=10, pady=(8,2), fill='x')
        lbl(r1,"층 선택:").pack(side='left')
        self.tf_v = tk.StringVar()
        self.fl_cb = combo(r1, self.tf_v, [], editable=False, width=8)
        self.fl_cb.pack(side='left', padx=4)
        lbl(r1,"객실번호:").pack(side='left', padx=(8,0))
        self.rn_v = tk.StringVar()
        entry(r1, self.rn_v, w=7).pack(side='left', padx=3)
        lbl(r1,"객실명:").pack(side='left', padx=(8,0))
        self.rname_v = tk.StringVar()
        entry(r1, self.rname_v, w=8).pack(side='left', padx=3)

        r2 = tk.Frame(rmf, bg=C['panel']); r2.pack(padx=10, pady=(2,8), fill='x')
        lbl(r2,"객실유형\n(직접입력):").pack(side='left')
        self.rtype_v = tk.StringVar(value='일반실')
        combo(r2, self.rtype_v,
              ['일반실','특실','스위트','VIP룸','가족룸','온돌방','비즈니스룸'],
              editable=True, width=12).pack(side='left', padx=4)
        lbl(r2,"기본요금:").pack(side='left', padx=(10,0))
        self.rrate_v = tk.StringVar(value='50000')
        entry(r2, self.rrate_v, w=9).pack(side='left', padx=3)
        lbl(r2,"원").pack(side='left', padx=2)
        btn(r2,"✅ 객실 추가 저장", self._add_room, C['green'], px=14, py=5, fs=9).pack(side='left', padx=14)

        # ── 트리 ──
        tk.Frame(self,bg=C['bg']).pack(fill='x',padx=16)
        lbl_r = tk.Frame(self,bg=C['bg']); lbl_r.pack(fill='x',padx=16)
        lbl(lbl_r,"현재 구조  (더블클릭 = 수정)", C['teal'], 9).pack(side='left')

        tf = tk.Frame(self, bg=C['bg']); tf.pack(fill='both', expand=True, padx=16, pady=4)
        cols = ('rname','rtype','rate','status')
        heads= ('객실명','유형','요금','상태')
        widths=(110,100,90,70)
        self.tree = ttk.Treeview(tf, style='D.Treeview',
                                  columns=cols, show='tree headings')
        self.tree.heading('#0', text='층/객실번호', anchor='w')
        for c,h,w in zip(cols,heads,widths):
            self.tree.heading(c,text=h); self.tree.column(c,width=w)
        self.tree.column('#0', width=160, minwidth=120)
        vsb=ttk.Scrollbar(tf,orient='vertical',command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side='left',fill='both',expand=True); vsb.pack(side='right',fill='y')
        self.tree.bind('<Double-1>', self._dbl)

        bf=tk.Frame(self,bg=C['bg']); bf.pack(pady=8)
        btn(bf,"✏️ 수정",self._edit, C['blue'],px=14,py=6,fs=9).pack(side='left',padx=5)
        btn(bf,"🗑️ 삭제",self._del,  C['red'], px=14,py=6,fs=9).pack(side='left',padx=5)

        self._refresh()

    def _refresh(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        floors = self.db.get_floors()
        labels = []
        for fl in floors:
            fi = self.tree.insert('','end', text=f"🏢 {fl['floor_name']}",
                                   values=(f"{len(fl['rooms'])}개 객실",'','',''),
                                   tags=(f"floor_{fl['id']}",), open=True)
            for rm in fl['rooms']:
                st,_,ic = STATUS_MAP.get(rm['status'], STATUS_MAP['vacant'])
                self.tree.insert(fi,'end', text=f"  {rm['room_number']}",
                                  values=(rm.get('room_name',''),rm.get('room_type',''),
                                          f"{rm.get('base_rate',0):,}원",f"{ic}{st}"),
                                  tags=(f"room_{rm['id']}",))
            labels.append(fl['floor_name'])
        self.fl_cb['values'] = labels
        if labels and not self.tf_v.get(): self.tf_v.set(labels[-1])

    def _add_floor(self):
        try: num = int(self.fn_v.get())
        except ValueError:
            messagebox.showerror("오류","층 번호는 숫자로 입력하세요.", parent=self); return
        name = self.fname_v.get().strip() or f"{num}층"
        if self.db.add_floor(num, name):
            self._refresh(); self.on_ok()
            self.fn_v.set(''); self.fname_v.set('')
        else:
            messagebox.showerror("오류",f"{num}층은 이미 존재합니다.", parent=self)

    def _add_room(self):
        fn = self.tf_v.get()
        if not fn: messagebox.showerror("오류","층을 선택하세요.", parent=self); return
        floors = self.db.get_floors()
        fl = next((f for f in floors if f['floor_name']==fn), None)
        if not fl: return
        rn = self.rn_v.get().strip()
        if not rn: messagebox.showerror("오류","객실 번호를 입력하세요.", parent=self); return
        try: rate = int(self.rrate_v.get().replace(',','') or '50000')
        except ValueError: rate = 50000
        rt = self.rtype_v.get().strip() or '일반실'
        if self.db.add_room(fl['id'], rn, self.rname_v.get().strip(), rt, rate):
            self._refresh(); self.on_ok()
            self.rn_v.set(''); self.rname_v.set('')
            messagebox.showinfo("완료", f"객실 '{rn}' 추가 저장 완료!", parent=self)
        else:
            messagebox.showerror("오류",f"'{rn}' 객실이 이미 존재합니다.", parent=self)

    def _get_sel(self):
        sel = self.tree.selection()
        if not sel: return None, None
        tags = self.tree.item(sel[0])['tags']
        if not tags: return None, None
        tag = tags[0]
        kind = 'floor' if tag.startswith('floor_') else 'room' if tag.startswith('room_') else None
        eid  = int(tag.split('_')[1]) if kind else None
        return kind, eid

    def _dbl(self, _):
        kind, eid = self._get_sel()
        if kind == 'room':
            rm = self.db.get_room(eid)
            if rm: RoomEditDlg(self, rm, self.db, lambda: [self._refresh(), self.on_ok()])

    def _edit(self):
        kind, eid = self._get_sel()
        if kind == 'room':
            rm = self.db.get_room(eid)
            if rm: RoomEditDlg(self, rm, self.db, lambda: [self._refresh(), self.on_ok()])
        else: messagebox.showinfo("안내","객실을 선택하세요.", parent=self)

    def _del(self):
        kind, eid = self._get_sel()
        if kind == 'floor':
            if messagebox.askyesno("층 삭제","이 층의 모든 객실도 삭제됩니다.", parent=self):
                self.db.delete_floor(eid); self._refresh(); self.on_ok()
        elif kind == 'room':
            rm = self.db.get_room(eid)
            if rm and rm.get('status')=='occupied':
                messagebox.showerror("오류","사용 중인 객실은 삭제 불가.", parent=self); return
            if messagebox.askyesno("객실 삭제","이 객실을 삭제하시겠습니까?", parent=self):
                self.db.delete_room(eid); self._refresh(); self.on_ok()
        else: messagebox.showinfo("안내","삭제할 항목을 선택하세요.", parent=self)


# ═══════════════════════════════════════════════════════════════════
# 고객 검색
# ═══════════════════════════════════════════════════════════════════
class SearchDlg(tk.Toplevel):
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db=db; self.title("고객 검색 / 투숙 이력")
        self.geometry("820x540"); self.configure(bg=C['bg']); self.transient(parent)
        style_tree(); self._ui()

    def _ui(self):
        lbl(self,"🔍 고객 검색 / 투숙 이력",C['white'],14,True).pack(pady=(12,4))
        sf=tk.Frame(self,bg=C['panel']); sf.pack(fill='x',padx=16,pady=4)
        lbl(sf,"이름/전화/객실").pack(side='left',padx=8)
        self.kw=tk.StringVar()
        e=entry(sf,self.kw,w=14); e.pack(side='left',padx=4); e.bind('<Return>',lambda _:self._search())
        lbl(sf,"시작일").pack(side='left',padx=(10,2))
        self.sd=tk.StringVar(); entry(sf,self.sd,w=11).pack(side='left')
        lbl(sf,"종료일").pack(side='left',padx=(8,2))
        self.ed=tk.StringVar(); entry(sf,self.ed,w=11).pack(side='left')
        btn(sf,"검색",self._search,C['blue'],px=10,py=3,fs=9).pack(side='left',padx=6)
        btn(sf,"전체",self._all,C['dgray'],px=8,py=3,fs=9).pack(side='left',padx=2)
        btn(sf,"📤 CSV",self._csv,C['orange'],px=8,py=3,fs=9).pack(side='left',padx=2)

        cols=('check_in','room_number','guest_name','guest_phone','stay_type','rate','payment_method','check_out')
        heads=('체크인','객실','성함','연락처','유형','요금','결제','체크아웃')
        widths=(130,60,80,100,80,75,80,130)
        tf=tk.Frame(self,bg=C['bg']); tf.pack(fill='both',expand=True,padx=16,pady=6)
        self.tree=ttk.Treeview(tf,columns=cols,show='headings',style='D.Treeview')
        for c,h,w in zip(cols,heads,widths):
            self.tree.heading(c,text=h); self.tree.column(c,width=w,minwidth=40)
        vsb=ttk.Scrollbar(tf,orient='vertical',command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side='left',fill='both',expand=True); vsb.pack(side='right',fill='y')
        self.st_lbl=lbl(self,"결과: 0건"); self.st_lbl.pack(pady=3)
        self._all()

    def _search(self): self._show(self.db.search_stays(self.kw.get().strip(),self.sd.get().strip() or None,self.ed.get().strip() or None))
    def _all(self):    self._show(self.db.search_stays())
    def _show(self, rows):
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in rows:
            self.tree.insert('','end',values=(r.get('check_in','')[:16],r.get('room_number',''),
                r.get('guest_name',''),r.get('guest_phone',''),r.get('stay_type',''),
                f"{r.get('rate',0):,}",r.get('payment_method',''),(r.get('check_out') or '')[:16]))
        self.st_lbl.config(text=f"결과: {len(rows)}건")

    def _csv(self):
        rows=self.db.search_stays(self.kw.get(),self.sd.get() or None,self.ed.get() or None)
        p=filedialog.asksaveasfilename(parent=self,defaultextension='.csv',
            filetypes=[('CSV','*.csv')],initialfile=f"고객이력_{datetime.date.today()}.csv")
        if not p: return
        with open(p,'w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f); w.writerow(['체크인','객실','성함','연락처','유형','요금','결제','체크아웃'])
            for r in rows: w.writerow([r.get('check_in','')[:16],r.get('room_number',''),
                r.get('guest_name',''),r.get('guest_phone',''),r.get('stay_type',''),
                r.get('rate',0),r.get('payment_method',''),(r.get('check_out') or '')[:16]])
        messagebox.showinfo("완료",f"저장됨: {p}", parent=self)


# ═══════════════════════════════════════════════════════════════════
# 변경 로그 뷰어
# ═══════════════════════════════════════════════════════════════════
class LogDlg(tk.Toplevel):
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db=db; self.title("변경 로그 — 모든 수정 이력")
        self.geometry("820x480"); self.configure(bg=C['bg']); self.transient(parent)
        style_tree(); self._ui()

    def _ui(self):
        lbl(self,"📋 변경 로그 (날짜/시간 자동 기록)",C['white'],14,True).pack(pady=(12,4))
        tf=tk.Frame(self,bg=C['bg']); tf.pack(fill='both',expand=True,padx=16,pady=6)
        cols=('log_time','category','action','target','before_val','after_val')
        heads=('시각','분류','동작','대상','변경 전','변경 후')
        widths=(145,70,70,100,155,175)
        self.tree=ttk.Treeview(tf,columns=cols,show='headings',style='D.Treeview')
        for c,h,w in zip(cols,heads,widths):
            self.tree.heading(c,text=h); self.tree.column(c,width=w,minwidth=40)
        vsb=ttk.Scrollbar(tf,orient='vertical',command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side='left',fill='both',expand=True); vsb.pack(side='right',fill='y')
        bf=tk.Frame(self,bg=C['bg']); bf.pack(pady=6)
        btn(bf,"🔄 새로고침",self._load,C['dgray'],px=12,py=5,fs=9).pack(side='left',padx=5)
        btn(bf,"📤 CSV",self._csv,C['orange'],px=12,py=5,fs=9).pack(side='left',padx=5)
        lbl(self,f"로그 파일: {LOG_FILE}",fs=8).pack(pady=2)
        self._load()

    def _load(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in self.db.get_logs():
            self.tree.insert('','end',values=(r.get('log_time',''),r.get('category',''),
                r.get('action',''),r.get('target',''),r.get('before_val',''),r.get('after_val','')))

    def _csv(self):
        rows=self.db.get_logs()
        p=filedialog.asksaveasfilename(parent=self,defaultextension='.csv',
            filetypes=[('CSV','*.csv')],initialfile=f"변경로그_{datetime.date.today()}.csv")
        if not p: return
        with open(p,'w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f); w.writerow(['시각','분류','동작','대상','변경전','변경후'])
            for r in rows: w.writerow([r.get('log_time',''),r.get('category',''),
                r.get('action',''),r.get('target',''),r.get('before_val',''),r.get('after_val','')])
        messagebox.showinfo("완료",f"저장됨: {p}", parent=self)


# ═══════════════════════════════════════════════════════════════════
# 일일 정산
# ═══════════════════════════════════════════════════════════════════
class ReportDlg(tk.Toplevel):
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db=db; self.title("일일 정산 리포트")
        self.geometry("720x520"); self.configure(bg=C['bg']); self.transient(parent)
        style_tree(); self._ui()

    def _ui(self):
        lbl(self,"📊 일일 정산",C['white'],14,True).pack(pady=(12,4))
        cf=tk.Frame(self,bg=C['panel']); cf.pack(fill='x',padx=16,pady=4)
        lbl(cf,"날짜:").pack(side='left',padx=8)
        self.dv=tk.StringVar(value=datetime.date.today().isoformat())
        entry(cf,self.dv,w=12).pack(side='left')
        btn(cf,"조회",self._load,C['blue'],px=10,py=3,fs=9).pack(side='left',padx=6)
        btn(cf,"오늘",lambda:[self.dv.set(datetime.date.today().isoformat()),self._load()],C['dgray'],px=8,py=3,fs=9).pack(side='left')
        btn(cf,"📤 CSV",self._csv,C['orange'],px=10,py=3,fs=9).pack(side='right',padx=8)
        self.summ=lbl(self,"날짜 입력 후 [조회]",C['yellow'],10)
        self.summ.pack(pady=4)
        cols=('check_in','room_number','guest_name','stay_type','rate','payment_method','approval_number')
        heads=('체크인','객실','성함','유형','요금','결제','승인번호')
        widths=(130,60,80,80,80,80,130)
        tf=tk.Frame(self,bg=C['bg']); tf.pack(fill='both',expand=True,padx=16,pady=4)
        self.tree=ttk.Treeview(tf,columns=cols,show='headings',style='D.Treeview')
        for c,h,w in zip(cols,heads,widths):
            self.tree.heading(c,text=h); self.tree.column(c,width=w,minwidth=40)
        vsb=ttk.Scrollbar(tf,orient='vertical',command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side='left',fill='both',expand=True); vsb.pack(side='right',fill='y')
        self._load()

    def _load(self):
        ds=self.dv.get().strip()
        rows=self.db.get_daily_report(ds)
        total=sum((r.get('payment_amount') or r.get('rate',0)) for r in rows if r.get('check_out'))
        card=sum((r.get('payment_amount') or r.get('rate',0)) for r in rows if '카드' in (r.get('payment_method','') or ''))
        cash=sum((r.get('payment_amount') or r.get('rate',0)) for r in rows if '현금' in (r.get('payment_method','') or ''))
        ins=sum(1 for r in rows if r.get('check_in','').startswith(ds))
        outs=sum(1 for r in rows if (r.get('check_out') or '').startswith(ds))
        self.summ.config(text=f"  {ds}  |  체크인:{ins}  체크아웃:{outs}  |  💳 카드:{card:,}  💵 현금:{cash:,}  |  합계:{total:,}원")
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in rows:
            rate=r.get('payment_amount') or r.get('rate',0)
            self.tree.insert('','end',values=(r.get('check_in','')[:16],r.get('room_number',''),
                r.get('guest_name',''),r.get('stay_type',''),f"{rate:,}",
                r.get('payment_method',''),r.get('approval_number','')))

    def _csv(self):
        rows=self.db.get_daily_report(self.dv.get().strip())
        p=filedialog.asksaveasfilename(parent=self,defaultextension='.csv',
            filetypes=[('CSV','*.csv')],initialfile=f"정산_{self.dv.get()}.csv")
        if not p: return
        with open(p,'w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f); w.writerow(['체크인','객실','성함','유형','요금','결제','승인번호'])
            for r in rows:
                rate=r.get('payment_amount') or r.get('rate',0)
                w.writerow([r.get('check_in','')[:16],r.get('room_number',''),r.get('guest_name',''),
                             r.get('stay_type',''),rate,r.get('payment_method',''),r.get('approval_number','')])
        messagebox.showinfo("완료",f"저장됨: {p}", parent=self)


# ═══════════════════════════════════════════════════════════════════
# 알림 바
# ═══════════════════════════════════════════════════════════════════
class NotifBar:
    def __init__(self, parent):
        self.f = tk.Frame(parent, bg=C['panel'], height=28)
        self.l = tk.Label(self.f, text="  ✅ 준비 완료", bg=C['panel'],
                           fg=C['gray'], font=('맑은 고딕',9), anchor='w')
        self.l.pack(fill='x', padx=10, pady=4)
        self._t = None

    def notify(self, msg, lvl='info', ms=5000):
        fg = {'info':C['teal'],'warn':C['orange'],'error':C['red'],'success':C['green']}.get(lvl,C['white'])
        ic = {'info':'ℹ️','warn':'⚠️','error':'❌','success':'✅'}.get(lvl,'•')
        self.l.config(text=f"  {ic} {msg}", fg=fg)
        if self._t: self.l.after_cancel(self._t)
        if ms > 0: self._t = self.l.after(ms, lambda: self.l.config(text="  ✅ 대기 중", fg=C['gray']))


# ═══════════════════════════════════════════════════════════════════
# 메인 애플리케이션
# ═══════════════════════════════════════════════════════════════════
class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()  # 설정창 먼저 띄울 때 main 숨김
        self.cfg  = Config()
        self.db   = None
        self.term = None

    def start(self):
        """첫 실행이면 설정 마법사, 아니면 바로 실행"""
        if not self.cfg['motel_name'] or self.cfg['motel_name'] == '해와달 모텔':
            # 처음 실행 또는 설정 미완료 — 마법사 먼저
            pass
        self.root.deiconify()
        self._init_main()
        if not CONFIG_FILE.exists():
            SetupWizard(self.root, self.cfg, self._after_setup)
        else:
            self._after_setup()

    def _after_setup(self):
        self.cfg.save()
        if self.db is None:
            self.db   = DB(self.cfg)
            self.term = CardTerminal(self.cfg)
        self._build_ui()
        self._refresh()
        if self.db.online:
            threading.Thread(target=self._bg_sync, daemon=True).start()
        self._clock()
        self._check_res()

    def _bg_sync(self):
        """백그라운드 클라우드 동기화"""
        try:
            self.db.cloud_sync_pull()
            self.root.after(0, self._refresh)
        except Exception:
            pass

    def _init_main(self):
        self.root.title(f"{APP_NAME} v{APP_VERSION}")
        self.root.geometry("1300x820"); self.root.minsize(1024,700)
        self.root.configure(bg=C['bg'])
        style_tree()

    def _build_ui(self):
        """메인 UI 구성"""
        for w in self.root.winfo_children(): w.destroy()
        self._menu()
        self._header()
        self.notif = NotifBar(self.root)
        self.notif.f.pack(fill='x')
        self._main_area()
        self._statusbar()

    # ──────── 메뉴바 ──────────────────────────────────────────────
    def _menu(self):
        mb = tk.Menu(self.root, bg=C['panel'], fg='white',
                     activebackground=C['accent'], activeforeground='white', relief='flat')
        self.root.config(menu=mb)
        def m(label):
            s=tk.Menu(mb,tearoff=0,bg=C['panel'],fg='white',
                       activebackground=C['accent'],activeforeground='white')
            mb.add_cascade(label=label,menu=s); return s

        s=m("⚙️ 시스템")
        s.add_command(label="초기 설정 (모텔정보/DB/단말기)", command=self._setup)
        s.add_separator()
        s.add_command(label="층/객실 구조 관리",  command=self._floor_mgr)
        s.add_separator()
        s.add_command(label="데이터 백업",          command=self._backup)
        s.add_command(label="데이터 복원",          command=self._restore)
        s.add_command(label="변경 로그 보기",       command=self._log)
        s.add_separator()
        s.add_command(label="클라우드 동기화 (수동)", command=self._sync)
        s.add_separator()
        s.add_command(label="🔐 직원 PIN 관리",      command=self._pin_mgr)
        s.add_separator()
        s.add_command(label="종료", command=self.root.quit)

        g=m("👥 고객관리")
        g.add_command(label="고객 검색 / 투숙 이력", command=self._search)
        g.add_command(label="예약 관리",             command=self._reservations)

        r=m("📊 정산")
        r.add_command(label="일일 정산",    command=self._report)
        r.add_command(label="CSV 내보내기", command=self._csv_today)

        h=m("❓ 도움말")
        h.add_command(label="클라우드 DB 설정 가이드", command=self._cloud_guide)
        h.add_command(label=f"버전 v{APP_VERSION}", command=self._about)

    # ──────── 헤더 ────────────────────────────────────────────────
    def _header(self):
        hf = tk.Frame(self.root, bg=C['card'], height=60)
        hf.pack(fill='x'); hf.pack_propagate(False)
        name = self.cfg['motel_name'] or '해와달 모텔'
        tk.Label(hf, text=f"🌙 {name}  PMS",
                 bg=C['card'], fg=C['yellow'],
                 font=('맑은 고딕',17,'bold')).pack(side='left',padx=20)
        self.clock_l = tk.Label(hf, text="", bg=C['card'], fg='white',
                                 font=('맑은 고딕',13,'bold'))
        self.clock_l.pack(side='right', padx=20)
        self.mode_l = tk.Label(hf, text="", bg=C['card'], fg=C['teal'],
                                font=('맑은 고딕',10,'bold'))
        self.mode_l.pack(side='right', padx=16)
        self.summ_l = tk.Label(hf, text="", bg=C['card'], fg=C['gray'],
                                font=('맑은 고딕',10))
        self.summ_l.pack(side='right', padx=20)

    # ──────── 메인 레이아웃 ───────────────────────────────────────
    def _main_area(self):
        mf = tk.Frame(self.root, bg=C['bg']); mf.pack(fill='both', expand=True)
        # 좌: 객실 그리드
        left = tk.Frame(mf, bg=C['bg']); left.pack(side='left', fill='both', expand=True)
        self.tab_f = tk.Frame(left, bg=C['panel']); self.tab_f.pack(fill='x')
        self.canvas = tk.Canvas(left, bg=C['bg'], highlightthickness=0)
        sy = ttk.Scrollbar(left, orient='vertical',   command=self.canvas.yview)
        sx = ttk.Scrollbar(left, orient='horizontal', command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        sy.pack(side='right', fill='y'); sx.pack(side='bottom', fill='x')
        self.canvas.pack(fill='both', expand=True)
        self.inner = tk.Frame(self.canvas, bg=C['bg'])
        self.cw = self.canvas.create_window((0,0), window=self.inner, anchor='nw')
        self.inner.bind('<Configure>',
                        lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',
                         lambda e: self.canvas.itemconfig(self.cw, width=e.width))
        self.canvas.bind('<MouseWheel>',
                         lambda e: self.canvas.yview_scroll(int(-1*(e.delta/120)),'units'))
        # 우: 제어 패널
        self._ctrl(mf)
        self.sel_room = None

    def _ctrl(self, parent):
        rp = tk.Frame(parent, bg=C['panel'], width=230)
        rp.pack(side='right', fill='y'); rp.pack_propagate(False)
        lbl(rp,"제어 패널",C['yellow'],12,True).pack(pady=(10,4))
        self.sel_lbl = tk.Label(rp, text="← 객실을 클릭하세요",
                                 bg=C['card'], fg=C['gray'],
                                 font=('맑은 고딕',9), wraplength=200,
                                 justify='center', pady=12)
        self.sel_lbl.pack(fill='x', padx=8, pady=6)

        for t, cmd, col in [
            ("✅ 체크인",    self._checkin,   C['green']),
            ("🚪 체크아웃", self._checkout,  C['red']),
            ("💳 카드결제", self._card,      C['blue']),
            ("💵 현금결제", self._cash,      C['green']),
            ("✏️ 객실 편집", self._edit_room, C['dgray']),
        ]:
            tk.Button(rp, text=t, command=cmd, bg=col, fg='white',
                      font=('맑은 고딕',11,'bold'), relief='flat',
                      pady=9, cursor='hand2').pack(fill='x', padx=8, pady=3)

        tk.Frame(rp, bg=C['dgray'], height=1).pack(fill='x', pady=8)
        lbl(rp,"빠른 메뉴", C['gray'], 9).pack()
        for t, cmd in [("🔍 고객 검색",self._search),
                        ("📅 예약 관리",self._reservations),
                        ("📊 일일 정산",self._report),
                        ("🏢 층/객실 관리",self._floor_mgr),
                        ("📋 변경 로그",self._log),
                        ("⚙️ 설정",self._setup)]:
            tk.Button(rp, text=t, command=cmd, bg=C['card'], fg=C['gray'],
                      font=('맑은 고딕',10), relief='flat',
                      pady=7, cursor='hand2').pack(fill='x', padx=8, pady=2)
        tk.Frame(rp,bg=C['panel'],height=2).pack(fill='x',pady=6)
        tk.Button(rp, text="🔄 새로고침", command=self._refresh,
                  bg=C['panel'], fg=C['teal'], font=('맑은 고딕',10),
                  relief='flat', pady=6, cursor='hand2').pack(fill='x', padx=8)

    def _statusbar(self):
        sb = tk.Frame(self.root, bg=C['card'], height=22)
        sb.pack(fill='x', side='bottom'); sb.pack_propagate(False)
        tk.Label(sb, text=f"  데이터 저장 위치: {DATA_DIR}",
                 bg=C['card'], fg=C['gray'], font=('맑은 고딕',8)).pack(side='left')
        tk.Label(sb, text=f"  {APP_NAME} v{APP_VERSION}  ",
                 bg=C['card'], fg=C['gray'], font=('맑은 고딕',8)).pack(side='right')

    # ──────── 객실 그리드 ─────────────────────────────────────────
    def _refresh(self):
        if not self.db: return
        for w in self.inner.winfo_children(): w.destroy()
        for w in self.tab_f.winfo_children(): w.destroy()
        floors = self.db.get_floors()
        all_rooms = [r for fl in floors for r in fl['rooms']]
        v=sum(1 for r in all_rooms if r['status']=='vacant')
        o=sum(1 for r in all_rooms if r['status']=='occupied')
        rsv=sum(1 for r in all_rooms if r['status']=='reserved')
        self.summ_l.config(text=f"공실:{v}  사용중:{o}  예약:{rsv}  전체:{len(all_rooms)}")
        self.mode_l.config(text=f"  {self.db.mode()}")

        tk.Button(self.tab_f, text="전체", bg=C['accent'], fg='white',
                  font=('맑은 고딕',9,'bold'), relief='flat', padx=12, pady=5,
                  cursor='hand2', command=lambda: self._show(floors)).pack(side='left',padx=2,pady=3)
        for fl in floors:
            tk.Button(self.tab_f, text=fl['floor_name'], bg=C['card'], fg='white',
                      font=('맑은 고딕',9), relief='flat', padx=10, pady=5,
                      cursor='hand2', command=lambda f=fl: self._show([f])).pack(side='left',padx=2,pady=3)
        self._show(floors)

    def _show(self, floors):
        for w in self.inner.winfo_children(): w.destroy()
        for fl in floors:
            hf = tk.Frame(self.inner, bg=C['card']); hf.pack(fill='x', padx=10, pady=(10,2))
            tk.Label(hf, text=f"  🏢 {fl['floor_name']}  ({len(fl['rooms'])}실)",
                     bg=C['card'], fg=C['yellow'],
                     font=('맑은 고딕',12,'bold')).pack(side='left', pady=6)
            gf = tk.Frame(self.inner, bg=C['bg']); gf.pack(fill='x', padx=10, pady=(0,4))
            cols=8
            for i, room in enumerate(fl['rooms']):
                RoomCard(gf, room, self._on_click, width=118, height=92
                         ).grid(row=i//cols, column=i%cols, padx=3, pady=3, sticky='nsew')
            for c in range(min(cols, len(fl['rooms']))): gf.grid_columnconfigure(c, weight=1)

    def _on_click(self, room):
        rm = self.db.get_room(room['id'])
        self.sel_room = rm or room
        st,_,ic = STATUS_MAP.get(self.sel_room['status'], STATUS_MAP['vacant'])
        self.sel_lbl.config(
            text=f"{self.sel_room['room_number']}\n"
                 f"{self.sel_room.get('room_name','')}\n"
                 f"{self.sel_room.get('room_type','')}\n"
                 f"{self.sel_room.get('base_rate',0):,}원\n"
                 f"{ic} {st}",
            fg=C['white'])

    # ──────── 제어 패널 액션 ──────────────────────────────────────
    def _need(self, status=None):
        if not self.sel_room:
            messagebox.showwarning("알림","먼저 객실을 클릭해서 선택하세요."); return False
        rm = self.db.get_room(self.sel_room['id'])
        if rm: self.sel_room = rm
        if status and self.sel_room.get('status') != status:
            messagebox.showwarning("알림",
                f"[{STATUS_MAP.get(status,['?'])[0]}] 상태 객실만 가능합니다.\n"
                f"현재: {STATUS_MAP.get(self.sel_room.get('status',''),[self.sel_room.get('status','')])[0]}")
            return False
        return True

    def _checkin(self):
        if not self._need('vacant'): return
        if not PinAuthDialog.ask(self.root, self.cfg): return
        CheckInDlg(self.root, self.sel_room, self.db, self.cfg,
                   on_ok=lambda: [self.notif.notify(f"✅ 체크인: {self.sel_room['room_number']}",'success'), self._refresh()])

    def _checkout(self):
        if not self._need('occupied'): return
        if not PinAuthDialog.ask(self.root, self.cfg): return
        stay = self.db.get_current_stay(self.sel_room['id'])
        if not stay: messagebox.showerror("오류","투숙 정보 없음"); return
        CheckOutDlg(self.root, self.sel_room, stay, self.db, self.term,
                    self.notif.notify, on_ok=self._refresh)

    def _pay(self, method):
        if not self.sel_room:
            messagebox.showwarning("알림","먼저 객실을 선택하세요."); return
        rm = self.db.get_room(self.sel_room['id'])
        if rm['status'] != 'occupied':
            messagebox.showwarning("알림","사용 중인 객실만 결제 가능합니다."); return
        stay = self.db.get_current_stay(rm['id'])
        if not stay: messagebox.showerror("오류","투숙 정보 없음"); return
        amt_s = simpledialog.askstring("결제 금액", f"금액 (객실: {rm['room_number']})",
                                        initialvalue=str(stay.get('rate',0)), parent=self.root)
        if amt_s is None: return
        try: amt = int(amt_s.replace(',',''))
        except ValueError: messagebox.showerror("오류","숫자로 입력하세요."); return
        if method=='card':
            self.notif.notify("💳 카드 결제 처리 중...","info",0); self.root.update()
            def _do():
                r = self.term.pay(amt, stay.get('guest_name',''), rm['room_number'])
                self.root.after(0, lambda: self._pay_done(r,'카드결제',rm,stay))
            threading.Thread(target=_do, daemon=True).start()
        else:
            r={'success':True,'amount':amt,'approval_number':f'CASH{int(time.time())}','error':''}
            self._pay_done(r,'현금결제',rm,stay)

    def _card(self): self._pay('card')
    def _cash(self): self._pay('cash')

    def _pay_done(self, r, method, rm, stay):
        if r['success']:
            self.db.checkout(rm['id'],stay['id'],method,r['amount'],r['approval_number'])
            self.notif.notify(f"✅ {method} — {r['amount']:,}원",'success')
            messagebox.showinfo("완료",f"{method} 완료!\n{r['amount']:,}원\n승인: {r['approval_number']}")
            self._refresh()
        else:
            self.notif.notify(f"❌ 실패: {r['error']}",'error')
            messagebox.showerror("실패",f"오류: {r['error']}")

    def _edit_room(self):
        if not self.sel_room: messagebox.showwarning("알림","먼저 객실을 선택하세요."); return
        rm = self.db.get_room(self.sel_room['id'])
        RoomEditDlg(self.root, rm, self.db, on_ok=self._refresh)

    # ──────── 메뉴 액션 ───────────────────────────────────────────
    def _setup(self):
        SetupWizard(self.root, self.cfg, on_done=lambda:[
            self.cfg.save(),
            setattr(self, 'db',   DB(self.cfg)),
            setattr(self, 'term', CardTerminal(self.cfg)),
            self._build_ui(), self._refresh()])

    def _floor_mgr(self):   FloorMgrDlg(self.root, self.db, on_ok=self._refresh)
    def _search(self):      SearchDlg(self.root, self.db)
    def _report(self):      ReportDlg(self.root, self.db)
    def _log(self):         LogDlg(self.root, self.db)

    def _sync(self):
        if not self.db.online:
            messagebox.showinfo("알림","클라우드에 연결되어 있지 않습니다.\n설정에서 Supabase URL/키를 확인하세요.")
            return
        self.notif.notify("☁️ 클라우드 동기화 중...", 'info', 0); self.root.update()
        def _do():
            ok = self.db.cloud_sync_pull()
            self.root.after(0, lambda: [
                self.notif.notify("✅ 동기화 완료" if ok else "❌ 동기화 실패",
                                  'success' if ok else 'error'),
                self._refresh()])
        threading.Thread(target=_do, daemon=True).start()

    def _reservations(self):
        win=tk.Toplevel(self.root); win.title("예약 관리")
        win.geometry("780x520"); win.configure(bg=C['bg']); win.transient(self.root)
        style_tree()
        lbl(win,"📅 예약 관리",C['white'],14,True).pack(pady=(12,4))
        af=tk.LabelFrame(win,text=" + 예약 추가 ",bg=C['panel'],fg=C['yellow'],font=('맑은 고딕',9,'bold'))
        af.pack(fill='x',padx=16,pady=4)
        r1=tk.Frame(af,bg=C['panel']); r1.pack(fill='x',padx=8,pady=5)
        labels=['객실번호','성함*','연락처','체크인(YYYY-MM-DD)','체크아웃']
        widths=[8,9,12,13,11]
        vs=[]
        for lt,w in zip(labels,widths):
            lbl(r1,lt,fs=8).pack(side='left',padx=(8,2))
            v=tk.StringVar(); vs.append(v)
            entry(r1,v,w=w,font_size=9).pack(side='left')
        r2=tk.Frame(af,bg=C['panel']); r2.pack(fill='x',padx=8,pady=3)
        rv=tk.StringVar(); rmv=tk.StringVar()
        lbl(r2,"요금",fs=8).pack(side='left',padx=(8,2))
        entry(r2,rv,w=10,font_size=9).pack(side='left')
        lbl(r2,"원  메모",fs=8).pack(side='left',padx=(4,2))
        entry(r2,rmv,w=20,font_size=9).pack(side='left')

        cols=('id','check_in_date','room_number','guest_name','guest_phone','rate','memo')
        tree=ttk.Treeview(win,columns=cols,show='headings',style='D.Treeview')
        for c,h,w in zip(cols,('ID','체크인','객실','성함','연락처','요금','메모'),(40,100,60,80,100,70,140)):
            tree.heading(c,text=h); tree.column(c,width=w,minwidth=30)

        def add():
            gn=vs[1].get().strip()
            if not gn: messagebox.showerror("오류","성함을 입력하세요.",parent=win); return
            try: rate=int(rv.get().replace(',','') or '0')
            except ValueError: rate=0
            self.db.add_reservation(vs[0].get().strip(),gn,vs[2].get().strip(),
                                     vs[3].get().strip(),vs[4].get().strip() or '',
                                     '숙박',rate,rmv.get().strip())
            self.notif.notify(f"📅 예약 추가: {gn}",'info'); _load()
            for v in vs: v.set('')
            rv.set(''); rmv.set('')

        def _load():
            for i in tree.get_children(): tree.delete(i)
            for row in self.db.get_reservations():
                tree.insert('','end',values=(row['id'],row.get('check_in_date',''),row.get('room_number',''),
                    row.get('guest_name',''),row.get('guest_phone',''),f"{row.get('rate',0):,}",row.get('memo','')))

        def cancel():
            sel=tree.selection()
            if not sel: messagebox.showinfo("알림","취소할 예약을 선택하세요.",parent=win); return
            rid=tree.item(sel[0])['values'][0]
            if messagebox.askyesno("취소",f"예약 ID {rid}를 취소하시겠습니까?",parent=win):
                self.db.cancel_reservation(rid); _load()

        btn(r2,"📌 예약 추가",add,C['blue'],px=12,py=3,fs=9).pack(side='left',padx=12)
        tf=tk.Frame(win,bg=C['bg']); tf.pack(fill='both',expand=True,padx=16,pady=4)
        vsb=ttk.Scrollbar(tf,orient='vertical',command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side='left',fill='both',expand=True); vsb.pack(side='right',fill='y')
        btn(win,"🗑️ 선택 취소",cancel,C['red'],px=12,py=5,fs=9).pack(pady=6)
        _load()

    def _backup(self):
        today=datetime.date.today().isoformat()
        p=filedialog.asksaveasfilename(defaultextension='.db',filetypes=[('DB','*.db')],
            initialfile=f"haewadal_backup_{today}.db")
        if p: shutil.copy2(str(DB_FILE),p); messagebox.showinfo("완료",f"백업 저장:\n{p}")

    def _restore(self):
        p=filedialog.askopenfilename(filetypes=[('DB','*.db')])
        if not p: return
        if messagebox.askyesno("복원 확인","현재 데이터를 백업 파일로 교체합니다.\n계속하시겠습니까?"):
            shutil.copy2(p, str(DB_FILE))
            messagebox.showinfo("완료","복원 완료. 프로그램을 재시작하세요.")

    def _csv_today(self):
        today=datetime.date.today().isoformat()
        rows=self.db.get_daily_report(today)
        p=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSV','*.csv')],
            initialfile=f"정산_{today}.csv")
        if not p: return
        with open(p,'w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f); w.writerow(['체크인','객실','성함','유형','요금','결제','승인번호'])
            for r in rows:
                rate=r.get('payment_amount') or r.get('rate',0)
                w.writerow([r.get('check_in','')[:16],r.get('room_number',''),r.get('guest_name',''),
                             r.get('stay_type',''),rate,r.get('payment_method',''),r.get('approval_number','')])
        messagebox.showinfo("완료",f"저장됨: {p}")

    def _cloud_guide(self):
        win=tk.Toplevel(self.root); win.title("클라우드 DB 설정 가이드")
        win.geometry("560x540"); win.configure(bg=C['bg']); win.transient(self.root)
        txt=tk.Text(win,bg=C['panel'],fg='white',font=('맑은 고딕',10),
                     relief='flat',padx=14,pady=10,wrap='word')
        txt.insert('1.0', """
╔═══════════════════════════════════════════╗
║   클라우드 DB (Supabase) 설정 가이드      ║
╚═══════════════════════════════════════════╝

【 Supabase 란? 】
 - Google이 투자한 오픈소스 PostgreSQL 클라우드
 - 무료 플랜: DB 500MB, 무제한 API 요청
 - 여러 PC에서 동시 접속, 실시간 데이터 공유
 - 인터넷 끊겨도 자동으로 로컬 저장 전환

【 처음 설정 방법 (5분) 】

Step 1. 계정 생성
  → https://supabase.com 접속
  → "Start your project" 클릭
  → GitHub 또는 이메일로 가입

Step 2. 프로젝트 생성
  → "New Project" 클릭
  → Name: haewadal-motel
  → Database Password: 원하는 비밀번호
  → Region: Northeast Asia (Seoul)
  → "Create new project" 클릭

Step 3. API 키 확인
  → 좌측 메뉴: Settings → API
  → "Project URL" 복사 (예: https://xxxx.supabase.co)
  → "anon public" 키 복사

Step 4. PMS에 입력
  → ⚙️ 시스템 → 초기 설정 → ☁️ 클라우드 DB 탭
  → URL과 API 키 붙여넣기
  → "클라우드 DB 사용" 체크
  → "🔗 연결 테스트" 후 "💾 저장"

【 판매 시 구매자 안내 】
  각 구매자가 위 과정을 따라 본인의 무료 계정을 만들고
  URL + 키를 PMS에 입력하면 됩니다.
  서로 다른 DB라 데이터가 완전히 분리됩니다.

【 여러 PC 동시 사용 방법 】
  같은 Supabase URL + 키를 여러 PC에 입력하면
  모든 PC가 동일한 클라우드 DB를 사용합니다.
  (프런트 PC + 방장 PC 동시 사용 가능)

【 오프라인 시 】
  인터넷 없으면 자동으로 로컬 SQLite 저장
  인터넷 연결되면 자동 동기화 재개
""")
        txt.config(state='disabled')
        txt.pack(fill='both',expand=True,padx=10,pady=10)

    def _about(self):
        messagebox.showinfo("버전 정보",
            f"해와달 모텔 PMS v{APP_VERSION}\n\n"
            f"데이터 폴더: {DATA_DIR}\n"
            f"DB 파일: {DB_FILE}\n"
            f"로그 파일: {LOG_FILE}\n\n"
            f"[v7.1 신규]\n"
            f"• AppData 영구저장\n"
            f"• Supabase 클라우드 DB\n"
            f"• 숙박유형 직접 입력\n"
            f"• 오프라인 자동 전환\n"
            f"• 직원 PIN 인증 시스템\n"
            f"• 에러 로그 자동 기록 ({ERROR_LOG.name})")

    # ──────── 시계 / 예약 체크 ────────────────────────────────────
    def _clock(self):
        def _u(): self.clock_l.config(text=datetime.datetime.now().strftime('%Y-%m-%d  %H:%M:%S')); self.root.after(1000,_u)
        _u()

    def _check_res(self):
        if not self.db: return
        today=datetime.date.today().isoformat()
        rsvs=[r for r in self.db.get_reservations() if r.get('check_in_date','').startswith(today)]
        if rsvs:
            names=', '.join(r['guest_name'] for r in rsvs[:3])
            self.notif.notify(f"📅 오늘 예약 {len(rsvs)}건: {names}",'info',10000)
        self.root.after(300000, self._check_res)

    def _pin_mgr(self):
        PinSettingsDlg(self.root, self.cfg)

    def run(self):
        self.root.mainloop()


# ═══════════════════════════════════════════════════════════════════
# 진입점
# ═══════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    try:
        app = App()
        app.start()
        app.run()
    except Exception as _e:
        log_error("치명적 오류 — 앱 크래시", _e)
        import tkinter as _tk, tkinter.messagebox as _mb
        try:
            _r = _tk.Tk(); _r.withdraw()
            _mb.showerror("오류",
                f"프로그램 실행 중 오류가 발생했습니다.\n\n"
                f"{type(_e).__name__}: {_e}\n\n"
                f"오류 로그: {ERROR_LOG}")
            _r.destroy()
        except Exception:
            pass
        raise

#!/bin/bash
# ═══════════════════════════════════════════════════
#  해와달 모텔 PMS v7.0 — Linux 실행 스크립트
# ═══════════════════════════════════════════════════

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BINARY="$SCRIPT_DIR/해와달_모텔_PMS_v7"
PY_FILE="$SCRIPT_DIR/haewadal_pms.py"

echo ""
echo "  ╔═══════════════════════════════════╗"
echo "  ║   해와달 모텔 PMS v7.0 시작 중   ║"
echo "  ╚═══════════════════════════════════╝"
echo ""

# ── 방법 1: 독립 바이너리 실행 ──────────────────
if [ -f "$BINARY" ]; then
    chmod +x "$BINARY"
    echo "  ✅ 독립 실행 바이너리로 시작합니다"
    echo "  📁 데이터 저장: ~/.config/HaeWaDalPMS/"
    echo ""
    "$BINARY"
    exit $?
fi

# ── 방법 2: Python 으로 실행 ────────────────────
if [ -f "$PY_FILE" ]; then
    if command -v python3 &>/dev/null; then
        # tkinter 설치 확인
        if ! python3 -c "import tkinter" 2>/dev/null; then
            echo "  ⚠️  tkinter가 없습니다. 설치 중..."
            if command -v apt-get &>/dev/null; then
                sudo apt-get install -y python3-tk
            elif command -v yum &>/dev/null; then
                sudo yum install -y python3-tkinter
            elif command -v dnf &>/dev/null; then
                sudo dnf install -y python3-tkinter
            elif command -v pacman &>/dev/null; then
                sudo pacman -S tk --noconfirm
            fi
        fi
        echo "  ✅ Python으로 시작합니다"
        echo "  📁 데이터 저장: ~/.config/HaeWaDalPMS/"
        echo ""
        python3 "$PY_FILE"
    else
        echo "  ❌ Python3가 설치되어 있지 않습니다."
        echo ""
        echo "  설치 방법:"
        echo "    Ubuntu/Debian : sudo apt-get install python3 python3-tk"
        echo "    Fedora/RHEL   : sudo dnf install python3 python3-tkinter"
        echo "    Arch Linux    : sudo pacman -S python tk"
        echo ""
        read -p "  엔터를 눌러 종료..."
        exit 1
    fi
    exit $?
fi

echo "  ❌ 실행 파일을 찾을 수 없습니다."
echo "  이 스크립트와 같은 폴더에 다음 중 하나가 있어야 합니다:"
echo "    • 해와달_모텔_PMS_v7  (독립 바이너리)"
echo "    • haewadal_pms.py     (Python 소스)"
read -p "  엔터를 눌러 종료..."
exit 1

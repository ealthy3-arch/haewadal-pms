"""Windows desktop motel room manager (Tkinter + SQLite).
v7.3 — P2: RBAC 역할 권한, 개인정보 라이프사이클(자동 익명화), 스키마 마이그레이션
"""
from __future__ import annotations

import csv
import hashlib
import io
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Literal
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

# ─────────────────────────────────────────────────────────────────────────────
# 상수
# ─────────────────────────────────────────────────────────────────────────────
SCHEMA_VERSION = 3          # 마이그레이션 버전 관리

STATUS_AVAILABLE  = "available"
STATUS_OCCUPIED   = "occupied"
STATUS_CLEANING   = "cleaning"
STATUS_INSPECTION = "inspection"
STATUS_BROKEN     = "broken"

VALID_STATUSES = frozenset([
    STATUS_AVAILABLE, STATUS_OCCUPIED,
    STATUS_CLEANING, STATUS_INSPECTION, STATUS_BROKEN,
])

CHECKOUT_NORMAL = "normal"
CHECKOUT_NOSHOW = "noshow"
CHECKOUT_REFUND = "refund"

# ── P2: 역할(Role) 정의 ──────────────────────────────────────────────────────
ROLE_ADMIN    = "admin"     # 전체 권한
ROLE_COUNTER  = "counter"   # 체크인/아웃/결제
ROLE_CLEANING = "cleaning"  # 청소 상태 변경만

# 역할별 허용 작업 목록 (action 문자열)
ROLE_PERMISSIONS: dict[str, frozenset[str]] = {
    ROLE_ADMIN: frozenset([
        "checkin", "checkout", "noshow", "refund",
        "set_cleaning", "set_inspection", "set_broken", "set_available",
        "daily_report", "export_csv", "anonymize", "manage_users",
    ]),
    ROLE_COUNTER: frozenset([
        "checkin", "checkout", "noshow", "refund",
        "set_cleaning", "set_available",
        "daily_report", "export_csv",
    ]),
    ROLE_CLEANING: frozenset([
        "set_cleaning", "set_available",
    ]),
}

# 개인정보 보관 기간 기본값 (일)
DEFAULT_RETENTION_DAYS = 365


# ─────────────────────────────────────────────────────────────────────────────
# 유틸
# ─────────────────────────────────────────────────────────────────────────────
def mask_phone(phone: str) -> str:
    """전화번호 마스킹: 01012345678 → 010-****-5678"""
    if not phone:
        return ""
    digits = "".join(c for c in phone if c.isdigit())
    if len(digits) == 11:
        return f"{digits[:3]}-****-{digits[7:]}"
    if len(digits) == 10:
        return f"{digits[:3]}-***-{digits[6:]}"
    return f"{'*' * max(0, len(digits) - 4)}{digits[-4:]}" if len(digits) >= 4 else "****"


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def today_iso() -> str:
    return date.today().isoformat()


# ─────────────────────────────────────────────────────────────────────────────
# 데이터 클래스
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class RoomView:
    room_number: str
    room_type: str
    status: str
    guest_name: str
    guest_phone: str
    checkin_at: str
    checkout_at: str
    price: int

    @property
    def masked_phone(self) -> str:
        return mask_phone(self.guest_phone)


@dataclass
class StayRecord:
    id: int
    room_number: str
    guest_name: str
    guest_phone: str
    checkin_at: str
    checkout_at: str
    final_price: int
    refund_amount: int
    checkout_type: str
    created_at: str

    @property
    def net_revenue(self) -> int:
        return self.final_price - self.refund_amount


@dataclass
class DailyReport:
    report_date: str
    total_checkins: int
    total_checkouts: int
    normal_count: int
    noshow_count: int
    refund_count: int
    gross_revenue: int
    total_refunds: int
    net_revenue: int
    room_breakdown: list[dict] = field(default_factory=list)


# ── P2: 직원 계정 ─────────────────────────────────────────────────────────────
@dataclass
class StaffAccount:
    id: int
    username: str
    role: str
    is_active: bool
    created_at: str


# ─────────────────────────────────────────────────────────────────────────────
# P2: 인증/권한 관리자
# ─────────────────────────────────────────────────────────────────────────────
class AuthManager:
    """직원 계정 + 역할 기반 접근 제어(RBAC)"""

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn
        self._current_user: StaffAccount | None = None

    # ── 속성 ─────────────────────────────────────────────────────────────────
    @property
    def current_user(self) -> StaffAccount | None:
        return self._current_user

    @property
    def is_logged_in(self) -> bool:
        return self._current_user is not None

    @property
    def current_role(self) -> str | None:
        return self._current_user.role if self._current_user else None

    # ── 로그인/로그아웃 ───────────────────────────────────────────────────────
    def login(self, username: str, pin: str) -> bool:
        """PIN 인증 후 로그인. 성공 시 True."""
        row = self.conn.execute(
            "SELECT * FROM staff WHERE username=? AND pin_hash=? AND is_active=1",
            (username.strip(), _sha256(pin)),
        ).fetchone()
        if row:
            self._current_user = StaffAccount(
                id=row["id"], username=row["username"],
                role=row["role"], is_active=bool(row["is_active"]),
                created_at=row["created_at"],
            )
            self._log_access("login")
            return True
        return False

    def logout(self) -> None:
        if self._current_user:
            self._log_access("logout")
        self._current_user = None

    # ── 권한 확인 ─────────────────────────────────────────────────────────────
    def can(self, action: str) -> bool:
        """현재 로그인 사용자가 action 을 수행할 수 있는지 반환."""
        if not self._current_user:
            return False
        return action in ROLE_PERMISSIONS.get(self._current_user.role, frozenset())

    def require(self, action: str) -> None:
        """권한 없으면 PermissionError 발생."""
        if not self.can(action):
            role = self._current_user.role if self._current_user else "미로그인"
            raise PermissionError(
                f"'{action}' 작업은 '{role}' 역할에서 허용되지 않습니다."
            )

    # ── 계정 관리 ─────────────────────────────────────────────────────────────
    def create_staff(self, username: str, pin: str, role: str) -> StaffAccount:
        if role not in ROLE_PERMISSIONS:
            raise ValueError(f"유효하지 않은 역할: {role}")
        if len(pin) < 4:
            raise ValueError("PIN은 4자리 이상이어야 합니다.")
        if self.conn.execute("SELECT 1 FROM staff WHERE username=?", (username,)).fetchone():
            raise ValueError(f"이미 존재하는 사용자: {username}")
        now = now_iso()
        cur = self.conn.execute(
            "INSERT INTO staff (username, pin_hash, role, is_active, created_at) VALUES (?,?,?,1,?)",
            (username.strip(), _sha256(pin), role, now),
        )
        self.conn.commit()
        return StaffAccount(id=cur.lastrowid, username=username, role=role,
                            is_active=True, created_at=now)

    def change_pin(self, username: str, new_pin: str) -> bool:
        if len(new_pin) < 4:
            raise ValueError("PIN은 4자리 이상이어야 합니다.")
        c = self.conn.execute(
            "UPDATE staff SET pin_hash=? WHERE username=?", (_sha256(new_pin), username)
        )
        self.conn.commit()
        return c.rowcount > 0

    def deactivate(self, username: str) -> bool:
        c = self.conn.execute(
            "UPDATE staff SET is_active=0 WHERE username=?", (username,)
        )
        self.conn.commit()
        return c.rowcount > 0

    def list_staff(self) -> list[StaffAccount]:
        rows = self.conn.execute(
            "SELECT id, username, role, is_active, created_at FROM staff ORDER BY role, username"
        ).fetchall()
        return [StaffAccount(**dict(r)) for r in rows]

    def has_any_admin(self) -> bool:
        return bool(self.conn.execute(
            "SELECT 1 FROM staff WHERE role='admin' AND is_active=1"
        ).fetchone())

    # ── 접근 로그 ─────────────────────────────────────────────────────────────
    def _log_access(self, event: str) -> None:
        if not self._current_user:
            return
        self.conn.execute(
            "INSERT INTO access_log (username, role, event, logged_at) VALUES (?,?,?,?)",
            (self._current_user.username, self._current_user.role, event, now_iso()),
        )
        self.conn.commit()

    def log_action(self, action: str, detail: str = "") -> None:
        """업무 작업 감사로그 기록"""
        if self._current_user:
            self.conn.execute(
                "INSERT INTO access_log (username, role, event, logged_at) VALUES (?,?,?,?)",
                (self._current_user.username, self._current_user.role,
                 f"{action}:{detail}", now_iso()),
            )
            self.conn.commit()

    def access_log(self, limit: int = 200) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM access_log ORDER BY logged_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────────────────────
# 스토어
# ─────────────────────────────────────────────────────────────────────────────
class MotelStore:
    def __init__(self, db_path: str = "motel_manager.db",
                 retention_days: int = DEFAULT_RETENTION_DAYS) -> None:
        self.db_path = db_path
        self.retention_days = retention_days
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._migrate()
        self._seed_rooms_if_empty()
        self.auth = AuthManager(self.conn)

    # ── 마이그레이션 (P2: 스키마 버전 관리) ──────────────────────────────────
    def _migrate(self) -> None:
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_version (version INTEGER PRIMARY KEY)"
        )
        row = self.conn.execute("SELECT MAX(version) AS v FROM schema_version").fetchone()
        current = row["v"] or 0

        if current < 1:
            self.conn.executescript("""
                CREATE TABLE IF NOT EXISTS rooms (
                    room_number TEXT PRIMARY KEY,
                    room_type   TEXT NOT NULL,
                    status      TEXT NOT NULL DEFAULT 'available',
                    guest_name  TEXT,
                    guest_phone TEXT,
                    checkin_at  TEXT,
                    checkout_at TEXT,
                    price       INTEGER DEFAULT 0,
                    updated_at  TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS stay_history (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    room_number   TEXT    NOT NULL,
                    guest_name    TEXT    NOT NULL,
                    guest_phone   TEXT,
                    checkin_at    TEXT    NOT NULL,
                    checkout_at   TEXT    NOT NULL,
                    final_price   INTEGER NOT NULL DEFAULT 0,
                    refund_amount INTEGER NOT NULL DEFAULT 0,
                    checkout_type TEXT    NOT NULL DEFAULT 'normal',
                    anonymized    INTEGER NOT NULL DEFAULT 0,
                    created_at    TEXT    NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_stay_checkout
                    ON stay_history (substr(checkout_at,1,10));
                CREATE INDEX IF NOT EXISTS idx_stay_checkin
                    ON stay_history (substr(checkin_at,1,10));
            """)
            self.conn.execute("INSERT INTO schema_version VALUES (1)")

        if current < 2:
            # P2: 직원 계정 테이블
            self.conn.executescript("""
                CREATE TABLE IF NOT EXISTS staff (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    username   TEXT UNIQUE NOT NULL,
                    pin_hash   TEXT NOT NULL,
                    role       TEXT NOT NULL DEFAULT 'counter',
                    is_active  INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS access_log (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    username  TEXT NOT NULL,
                    role      TEXT NOT NULL,
                    event     TEXT NOT NULL,
                    logged_at TEXT NOT NULL
                );
            """)
            self.conn.execute("INSERT INTO schema_version VALUES (2)")

        if current < 3:
            # P2: 개인정보 익명화 컬럼 + 보관 정책 테이블
            try:
                self.conn.execute(
                    "ALTER TABLE stay_history ADD COLUMN anonymized INTEGER NOT NULL DEFAULT 0"
                )
            except sqlite3.OperationalError:
                pass  # 이미 존재
            self.conn.executescript("""
                CREATE TABLE IF NOT EXISTS privacy_policy (
                    id             INTEGER PRIMARY KEY,
                    retention_days INTEGER NOT NULL DEFAULT 365,
                    updated_at     TEXT    NOT NULL
                );
            """)
            # 기본 정책 삽입
            self.conn.execute(
                "INSERT OR IGNORE INTO privacy_policy (id, retention_days, updated_at) VALUES (1,?,?)",
                (DEFAULT_RETENTION_DAYS, now_iso()),
            )
            self.conn.execute("INSERT INTO schema_version VALUES (3)")

        self.conn.commit()

    def _seed_rooms_if_empty(self) -> None:
        if self.conn.execute("SELECT COUNT(*) FROM rooms").fetchone()[0] > 0:
            return
        now = now_iso()
        types = ["standard", "ondol", "twin", "couple", "longterm"]
        batch = [
            (f"{fl}{idx:02d}", types[(idx - 1) % len(types)], STATUS_AVAILABLE, now)
            for fl in [1, 2, 3]
            for idx in range(1, 11)
        ]
        self.conn.executemany(
            "INSERT INTO rooms (room_number, room_type, status, updated_at) VALUES (?,?,?,?)",
            batch,
        )
        self.conn.commit()

    # ── 조회 ─────────────────────────────────────────────────────────────────
    def list_rooms(self) -> list[RoomView]:
        rows = self.conn.execute("""
            SELECT room_number, room_type, status,
                   COALESCE(guest_name,  '') AS guest_name,
                   COALESCE(guest_phone, '') AS guest_phone,
                   COALESCE(checkin_at,  '') AS checkin_at,
                   COALESCE(checkout_at, '') AS checkout_at,
                   COALESCE(price, 0)        AS price
            FROM rooms ORDER BY room_number
        """).fetchall()
        return [RoomView(**dict(r)) for r in rows]

    # ── 상태 변경 ─────────────────────────────────────────────────────────────
    def set_available(self, rn: str)  -> None: self._set_status(rn, STATUS_AVAILABLE)
    def set_cleaning(self, rn: str)   -> None: self._set_status(rn, STATUS_CLEANING)
    def set_inspection(self, rn: str) -> None: self._set_status(rn, STATUS_INSPECTION)
    def set_broken(self, rn: str)     -> None: self._set_status(rn, STATUS_BROKEN)

    def _set_status(self, room_number: str, status: str) -> None:
        if status not in VALID_STATUSES:
            raise ValueError(f"유효하지 않은 상태: {status}")
        self.conn.execute(
            "UPDATE rooms SET status=?, updated_at=? WHERE room_number=?",
            (status, now_iso(), room_number),
        )
        self.conn.commit()

    # ── 체크인 ────────────────────────────────────────────────────────────────
    def check_in(self, room_number: str, guest_name: str, guest_phone: str,
                 checkout_at: str, price: int) -> None:
        self.conn.execute("""
            UPDATE rooms
            SET status='occupied', guest_name=?, guest_phone=?,
                checkin_at=?, checkout_at=?, price=?, updated_at=?
            WHERE room_number=?
        """, (guest_name, guest_phone, now_iso(), checkout_at, price, now_iso(), room_number))
        self.conn.commit()

    # ── 체크아웃 ──────────────────────────────────────────────────────────────
    def check_out(self, room_number: str) -> StayRecord | None:
        return self._do_checkout(room_number, CHECKOUT_NORMAL, 0)

    def check_out_noshow(self, room_number: str, penalty: int = 0) -> StayRecord | None:
        return self._do_checkout(room_number, CHECKOUT_NOSHOW, 0, override_price=penalty)

    # ── 환불 ──────────────────────────────────────────────────────────────────
    def refund_stay(self, stay_id: int, refund_amount: int) -> bool:
        row = self.conn.execute(
            "SELECT final_price, refund_amount FROM stay_history WHERE id=?", (stay_id,)
        ).fetchone()
        if not row:
            return False
        max_refund = row["final_price"] - row["refund_amount"]
        if refund_amount > max_refund:
            raise ValueError(
                f"환불 금액({refund_amount:,}원)이 잔여 결제액({max_refund:,}원)을 초과합니다."
            )
        self.conn.execute(
            "UPDATE stay_history SET refund_amount=refund_amount+?, checkout_type=? WHERE id=?",
            (refund_amount, CHECKOUT_REFUND, stay_id),
        )
        self.conn.commit()
        return True

    def _do_checkout(self, room_number: str, checkout_type: str,
                     refund_amount: int, override_price: int | None = None) -> StayRecord | None:
        room = self.conn.execute(
            "SELECT * FROM rooms WHERE room_number=?", (room_number,)
        ).fetchone()
        if not room or room["status"] != STATUS_OCCUPIED:
            return None
        co_time = now_iso()
        price = override_price if override_price is not None else (room["price"] or 0)
        cur = self.conn.execute("""
            INSERT INTO stay_history
                (room_number, guest_name, guest_phone, checkin_at, checkout_at,
                 final_price, refund_amount, checkout_type, anonymized, created_at)
            VALUES (?,?,?,?,?,?,?,?,0,?)
        """, (room["room_number"], room["guest_name"] or "-", room["guest_phone"] or "",
              room["checkin_at"] or co_time, co_time, price, refund_amount, checkout_type, co_time))
        stay_id = cur.lastrowid
        self.conn.execute("""
            UPDATE rooms SET status='available', guest_name=NULL, guest_phone=NULL,
                checkin_at=NULL, checkout_at=NULL, price=0, updated_at=?
            WHERE room_number=?
        """, (co_time, room_number))
        self.conn.commit()
        return StayRecord(id=stay_id, room_number=room["room_number"],
                          guest_name=room["guest_name"] or "-", guest_phone=room["guest_phone"] or "",
                          checkin_at=room["checkin_at"] or co_time, checkout_at=co_time,
                          final_price=price, refund_amount=refund_amount,
                          checkout_type=checkout_type, created_at=co_time)

    # ── P2: 개인정보 익명화 ───────────────────────────────────────────────────
    def anonymize_old_records(self, before_date: str | None = None,
                               retention_days: int | None = None) -> int:
        """
        보관 기간이 지난 투숙 이력의 개인정보를 익명화.
        before_date: 'YYYY-MM-DD' 기준일 (None이면 오늘 - retention_days)
        retention_days: None이면 DB 정책 또는 기본값 사용
        반환: 익명화된 행 수
        """
        days = retention_days
        if days is None:
            row = self.conn.execute(
                "SELECT retention_days FROM privacy_policy WHERE id=1"
            ).fetchone()
            days = row["retention_days"] if row else DEFAULT_RETENTION_DAYS

        if before_date is None:
            cutoff = (date.today() - timedelta(days=days)).isoformat()
        else:
            cutoff = before_date

        cur = self.conn.execute("""
            UPDATE stay_history
            SET guest_name  = '[익명]',
                guest_phone = '',
                anonymized  = 1
            WHERE anonymized = 0
              AND substr(checkout_at, 1, 10) < ?
        """, (cutoff,))
        self.conn.commit()
        return cur.rowcount

    def get_retention_policy(self) -> int:
        row = self.conn.execute(
            "SELECT retention_days FROM privacy_policy WHERE id=1"
        ).fetchone()
        return row["retention_days"] if row else DEFAULT_RETENTION_DAYS

    def set_retention_policy(self, days: int) -> None:
        if days < 30:
            raise ValueError("보관 기간은 최소 30일 이상이어야 합니다.")
        self.conn.execute(
            "UPDATE privacy_policy SET retention_days=?, updated_at=? WHERE id=1",
            (days, now_iso()),
        )
        self.conn.commit()

    def anonymization_stats(self) -> dict[str, int]:
        row = self.conn.execute("""
            SELECT
                SUM(CASE WHEN anonymized=0 THEN 1 ELSE 0 END) AS active,
                SUM(CASE WHEN anonymized=1 THEN 1 ELSE 0 END) AS anonymized
            FROM stay_history
        """).fetchone()
        return {
            "active":     row["active"]     or 0,
            "anonymized": row["anonymized"] or 0,
        }

    # ── 일마감 정산 ───────────────────────────────────────────────────────────
    def daily_report(self, report_date: str | None = None) -> DailyReport:
        d = report_date or today_iso()
        ci_count = self.conn.execute(
            "SELECT COUNT(*) FROM stay_history WHERE substr(checkin_at,1,10)=?", (d,)
        ).fetchone()[0]
        rows = self.conn.execute("""
            SELECT id, room_number, guest_name, guest_phone,
                   checkin_at, checkout_at, final_price, refund_amount, checkout_type
            FROM stay_history WHERE substr(checkout_at,1,10)=?
            ORDER BY checkout_at
        """, (d,)).fetchall()

        normal = noshow = refund_ct = gross = total_refunds = 0
        breakdown = []
        for r in rows:
            ct = r["checkout_type"]
            if ct == CHECKOUT_NOSHOW:   noshow    += 1
            elif ct == CHECKOUT_REFUND: refund_ct += 1
            else:                       normal    += 1
            gross         += r["final_price"]
            total_refunds += r["refund_amount"]
            breakdown.append({
                "id":            r["id"], "room_number": r["room_number"],
                "guest_name":    r["guest_name"],
                "guest_phone":   mask_phone(r["guest_phone"] or ""),
                "final_price":   r["final_price"], "refund_amount": r["refund_amount"],
                "net":           r["final_price"] - r["refund_amount"],
                "checkout_type": ct, "checkout_at": r["checkout_at"],
            })
        return DailyReport(
            report_date=d, total_checkins=ci_count, total_checkouts=len(rows),
            normal_count=normal, noshow_count=noshow, refund_count=refund_ct,
            gross_revenue=gross, total_refunds=total_refunds,
            net_revenue=gross - total_refunds, room_breakdown=breakdown,
        )

    def export_daily_report_csv(self, report_date: str | None = None) -> str:
        rpt = self.daily_report(report_date)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["날짜", rpt.report_date])
        w.writerow(["체크인", rpt.total_checkins, "체크아웃", rpt.total_checkouts])
        w.writerow(["정상", rpt.normal_count, "노쇼", rpt.noshow_count, "환불", rpt.refund_count])
        w.writerow(["총매출", rpt.gross_revenue, "총환불", rpt.total_refunds, "순매출", rpt.net_revenue])
        w.writerow([])
        w.writerow(["객실","고객명","전화(마스킹)","결제액","환불액","순액","유형","체크아웃시각"])
        for b in rpt.room_breakdown:
            w.writerow([b["room_number"], b["guest_name"], b["guest_phone"],
                        b["final_price"], b["refund_amount"], b["net"],
                        b["checkout_type"], b["checkout_at"]])
        return buf.getvalue()

    # ── 통계 ──────────────────────────────────────────────────────────────────
    def stats(self) -> dict[str, int]:
        c = self.conn.execute("""
            SELECT SUM(CASE WHEN status='available'  THEN 1 ELSE 0 END) AS available,
                   SUM(CASE WHEN status='occupied'   THEN 1 ELSE 0 END) AS occupied,
                   SUM(CASE WHEN status='cleaning'   THEN 1 ELSE 0 END) AS cleaning,
                   SUM(CASE WHEN status='inspection' THEN 1 ELSE 0 END) AS inspection,
                   SUM(CASE WHEN status='broken'     THEN 1 ELSE 0 END) AS broken
            FROM rooms
        """).fetchone()
        return {
            "available": c["available"] or 0, "occupied":   c["occupied"]   or 0,
            "cleaning":  c["cleaning"]  or 0, "inspection": c["inspection"] or 0,
            "broken":    c["broken"]    or 0,
            "today_revenue": self.daily_report().net_revenue,
        }

    def schema_version(self) -> int:
        row = self.conn.execute("SELECT MAX(version) AS v FROM schema_version").fetchone()
        return row["v"] or 0


# ─────────────────────────────────────────────────────────────────────────────
# UI (테스트 대상은 MotelStore + AuthManager)
# ─────────────────────────────────────────────────────────────────────────────
class MotelManagerApp:
    STATUS_LABELS = {
        STATUS_AVAILABLE:"이용가능", STATUS_OCCUPIED:"사용중",
        STATUS_CLEANING:"청소중",    STATUS_INSPECTION:"점검중",
        STATUS_BROKEN:"고장",
    }

    def __init__(self, root: tk.Tk, store: MotelStore) -> None:
        self.root = root
        self.store = store
        self.auth  = store.auth
        self.root.title("해와달 모텔 관리 시스템 v7.3")
        self.root.geometry("1180x700")
        self._build_ui()
        self._login_prompt()
        self.refresh()

    # ── 초기 로그인 ───────────────────────────────────────────────────────────
    def _login_prompt(self) -> None:
        if not self.auth.has_any_admin():
            # 최초 실행 — 관리자 계정 생성
            messagebox.showinfo("최초 설정",
                "최초 실행입니다.\n관리자 계정을 생성해 주세요.")
            self._create_first_admin()
        self._do_login()

    def _create_first_admin(self) -> None:
        while True:
            username = simpledialog.askstring("관리자 계정 생성","아이디") or ""
            pin      = simpledialog.askstring("관리자 계정 생성","PIN (4자리+)", show="*") or ""
            if not username or not pin:
                if messagebox.askyesno("확인","취소하면 앱이 종료됩니다. 계속 취소하시겠습니까?"):
                    self.root.destroy(); return
                continue
            try:
                self.auth.create_staff(username, pin, ROLE_ADMIN)
                messagebox.showinfo("완료",f"관리자 '{username}' 생성 완료")
                break
            except ValueError as e:
                messagebox.showerror("오류",str(e))

    def _do_login(self) -> None:
        while True:
            username = simpledialog.askstring("로그인","아이디") or ""
            pin      = simpledialog.askstring("로그인","PIN", show="*") or ""
            if self.auth.login(username, pin):
                u = self.auth.current_user
                self.root.title(
                    f"해와달 모텔 PMS v7.3  |  {u.username} ({u.role})"
                )
                break
            else:
                messagebox.showerror("인증 실패","아이디 또는 PIN이 올바르지 않습니다.")

    def _guard(self, action: str) -> bool:
        try:
            self.auth.require(action); return True
        except PermissionError as e:
            messagebox.showerror("권한 없음", str(e)); return False

    # ── UI 구성 ───────────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        top = ttk.Frame(self.root, padding=10)
        top.pack(fill="x")
        self.stats_label = ttk.Label(top, text="로딩 중...")
        self.stats_label.pack(side="left")

        for label, cmd in [
            ("새로고침",      self.refresh),
            ("체크인",        self.checkin),
            ("체크아웃",      self.checkout),
            ("노쇼",          self.checkout_noshow),
            ("환불",          self.refund),
            ("청소중",        lambda: self._set(STATUS_CLEANING)),
            ("점검중",        lambda: self._set(STATUS_INSPECTION)),
            ("고장",          lambda: self._set(STATUS_BROKEN)),
            ("이용가능",      lambda: self._set(STATUS_AVAILABLE)),
            ("일마감 리포트", self.show_daily_report),
            ("직원 관리",     self.manage_staff),
            ("개인정보 관리", self.privacy_panel),
        ]:
            ttk.Button(top, text=label, command=cmd).pack(side="right", padx=2)

        cols = ("room_number","room_type","status","guest_name","guest_phone",
                "checkin_at","checkout_at","price")
        self.tree = ttk.Treeview(self.root, columns=cols, show="headings")
        for col, head, w in [
            ("room_number","객실번호",80),("room_type","유형",90),("status","상태",80),
            ("guest_name","고객명",120),("guest_phone","전화(마스킹)",130),
            ("checkin_at","체크인",150),("checkout_at","체크아웃예정",150),("price","요금",90),
        ]:
            self.tree.heading(col, text=head)
            self.tree.column(col, width=w, anchor="center")
        self.tree.pack(fill="both", expand=True, padx=10, pady=(0,10))

    def _selected_room(self) -> str | None:
        item = self.tree.focus()
        if not item:
            messagebox.showwarning("선택 필요","객실을 먼저 선택해주세요."); return None
        return self.tree.item(item,"values")[0]

    def refresh(self) -> None:
        for item in self.tree.get_children(): self.tree.delete(item)
        for room in self.store.list_rooms():
            self.tree.insert("","end", values=(
                room.room_number, room.room_type,
                self.STATUS_LABELS.get(room.status, room.status),
                room.guest_name, room.masked_phone,
                room.checkin_at, room.checkout_at, f"{room.price:,}",
            ))
        s = self.store.stats()
        self.stats_label.config(text=(
            f"이용가능 {s['available']} | 사용중 {s['occupied']} | "
            f"청소중 {s['cleaning']} | 점검중 {s['inspection']} | 고장 {s['broken']}"
            f"  |  오늘 순매출 {s['today_revenue']:,}원"
        ))

    # ── 작업 핸들러 ───────────────────────────────────────────────────────────
    def checkin(self) -> None:
        if not self._guard("checkin"): return
        rn = self._selected_room()
        if not rn: return
        name = simpledialog.askstring("체크인","고객명")
        if not name: return
        phone    = simpledialog.askstring("체크인","전화번호") or ""
        checkout = simpledialog.askstring("체크인","예상 체크아웃 (예: 2026-06-01T12:00)",initialvalue="") or ""
        price_raw= simpledialog.askstring("체크인","요금(숫자)",initialvalue="50000")
        if not price_raw: return
        try: price = int(price_raw)
        except ValueError: messagebox.showerror("오류","숫자를 입력하세요."); return
        self.store.check_in(rn, name, phone, checkout, price)
        self.auth.log_action("checkin", f"{rn}/{name}")
        self.refresh()

    def checkout(self) -> None:
        if not self._guard("checkout"): return
        rn = self._selected_room()
        if not rn: return
        rec = self.store.check_out(rn)
        if rec:
            self.auth.log_action("checkout", f"{rn}/#{rec.id}/{rec.final_price}원")
            messagebox.showinfo("체크아웃 완료",
                f"객실 {rn}  고객: {rec.guest_name}\n결제액: {rec.final_price:,}원\nID: #{rec.id}")
        self.refresh()

    def checkout_noshow(self) -> None:
        if not self._guard("noshow"): return
        rn = self._selected_room()
        if not rn: return
        p_raw = simpledialog.askstring("노쇼 처리","위약금 (없으면 0)",initialvalue="0") or "0"
        try: penalty = int(p_raw)
        except ValueError: penalty = 0
        rec = self.store.check_out_noshow(rn, penalty)
        if rec:
            self.auth.log_action("noshow", f"{rn}/위약금:{penalty}원")
            messagebox.showinfo("노쇼 처리",f"객실 {rn} 노쇼\n위약금: {rec.final_price:,}원  ID: #{rec.id}")
        else:
            messagebox.showwarning("알림","해당 객실은 체크인 상태가 아닙니다.")
        self.refresh()

    def refund(self) -> None:
        if not self._guard("refund"): return
        sid_raw = simpledialog.askstring("환불","이력 ID")
        if not sid_raw: return
        try: sid = int(sid_raw)
        except ValueError: messagebox.showerror("오류","숫자 ID 입력"); return
        amt_raw = simpledialog.askstring("환불","환불 금액")
        if not amt_raw: return
        try: amt = int(amt_raw)
        except ValueError: messagebox.showerror("오류","숫자 입력"); return
        try:
            if self.store.refund_stay(sid, amt):
                self.auth.log_action("refund", f"ID#{sid}/{amt}원")
                messagebox.showinfo("환불 완료",f"이력 #{sid}에 {amt:,}원 환불 완료")
            else:
                messagebox.showerror("오류","ID를 찾을 수 없습니다.")
        except ValueError as e:
            messagebox.showerror("환불 오류",str(e))

    def _set(self, status: str) -> None:
        action_map = {
            STATUS_CLEANING:"set_cleaning",   STATUS_INSPECTION:"set_inspection",
            STATUS_BROKEN:"set_broken",        STATUS_AVAILABLE:"set_available",
        }
        if not self._guard(action_map.get(status,"")): return
        rn = self._selected_room()
        if not rn: return
        getattr(self.store, f"set_{status}")(rn)
        self.auth.log_action(f"set_{status}", rn)
        self.refresh()

    def show_daily_report(self) -> None:
        if not self._guard("daily_report"): return
        d = simpledialog.askstring("일마감 정산","날짜 (YYYY-MM-DD)",
                                   initialvalue=today_iso()) or today_iso()
        rpt = self.store.daily_report(d)
        win = tk.Toplevel(self.root); win.title(f"일마감 정산 — {d}"); win.geometry("780x520")
        tk.Label(win, justify="left", font=("맑은 고딕",10,"bold"), padx=12, pady=10, text=(
            f"날짜: {rpt.report_date}   체크인: {rpt.total_checkins}건  체크아웃: {rpt.total_checkouts}건\n"
            f"정상: {rpt.normal_count}  노쇼: {rpt.noshow_count}  환불처리: {rpt.refund_count}\n"
            f"총 매출: {rpt.gross_revenue:,}원  |  총 환불: {rpt.total_refunds:,}원  |  순 매출: {rpt.net_revenue:,}원"
        )).pack(anchor="w")
        ttk.Separator(win).pack(fill="x", padx=10)
        cols = ("room_number","guest_name","guest_phone","final_price","refund_amount","net","checkout_type","checkout_at")
        tree = ttk.Treeview(win, columns=cols, show="headings", height=14)
        for col,head,w in [
            ("room_number","객실",60),("guest_name","고객명",100),("guest_phone","전화",120),
            ("final_price","결제액",80),("refund_amount","환불액",70),("net","순액",80),
            ("checkout_type","유형",70),("checkout_at","체크아웃",140),
        ]:
            tree.heading(col,text=head); tree.column(col,width=w,anchor="center")
        for b in rpt.room_breakdown:
            tree.insert("","end",values=(b["room_number"],b["guest_name"],b["guest_phone"],
                f"{b['final_price']:,}",f"{b['refund_amount']:,}",f"{b['net']:,}",
                b["checkout_type"],b["checkout_at"]))
        tree.pack(fill="both",expand=True,padx=10,pady=8)

        def export_csv():
            if not self._guard("export_csv"): return
            fpath = Path.home() / f"정산_{d}.csv"
            fpath.write_text(self.store.export_daily_report_csv(d), encoding="utf-8-sig")
            messagebox.showinfo("내보내기",f"저장됨: {fpath}")
        ttk.Button(win,text="📥 CSV",command=export_csv).pack(pady=6)

    def manage_staff(self) -> None:
        if not self._guard("manage_users"): return
        win = tk.Toplevel(self.root); win.title("직원 계정 관리"); win.geometry("500x420")
        def refresh_list():
            for w in list_f.winfo_children(): w.destroy()
            for s in self.auth.list_staff():
                f = tk.Frame(list_f); f.pack(fill="x", padx=8, pady=2)
                status = "✅" if s.is_active else "❌"
                tk.Label(f, text=f"{status} {s.username:15s} [{s.role}]",
                         font=("맑은 고딕",10), width=30, anchor="w").pack(side="left")
                tk.Button(f, text="비활성화", command=lambda n=s.username: (
                    self.auth.deactivate(n), refresh_list()
                ), fg="red", padx=4).pack(side="right")

        tk.Label(win, text="👥 직원 목록", font=("맑은 고딕",11,"bold")).pack(pady=8)
        list_f = tk.Frame(win); list_f.pack(fill="both", expand=True, padx=10)
        refresh_list()
        ttk.Separator(win).pack(fill="x", padx=10, pady=4)
        tk.Label(win, text="새 계정 추가", font=("맑은 고딕",10,"bold")).pack()
        row = tk.Frame(win); row.pack(padx=10, pady=4)
        un_v = tk.StringVar(); pin_v = tk.StringVar(); role_v = tk.StringVar(value=ROLE_COUNTER)
        for lbl, var, show in [("아이디",un_v,False),("PIN",pin_v,True)]:
            tk.Label(row,text=lbl).pack(side="left")
            e = tk.Entry(row, textvariable=var, width=10); e.pack(side="left", padx=4)
            if show: e.config(show="*")
        ttk.Combobox(row, textvariable=role_v,
                     values=[ROLE_ADMIN, ROLE_COUNTER, ROLE_CLEANING],
                     width=10, state="readonly").pack(side="left", padx=4)

        def add():
            try:
                self.auth.create_staff(un_v.get(), pin_v.get(), role_v.get())
                un_v.set(""); pin_v.set(""); refresh_list()
            except ValueError as e: messagebox.showerror("오류",str(e),parent=win)
        tk.Button(win, text="추가", command=add, bg="#27ae60", fg="white").pack(pady=6)

    def privacy_panel(self) -> None:
        if not self._guard("anonymize"): return
        stats = self.store.anonymization_stats()
        days  = self.store.get_retention_policy()
        win   = tk.Toplevel(self.root); win.title("개인정보 보관 관리"); win.geometry("420x320")
        tk.Label(win, text="🔒 개인정보 라이프사이클 관리",
                 font=("맑은 고딕",11,"bold")).pack(pady=10)
        tk.Label(win, text=(
            f"투숙 이력: 개인정보 보존 {stats['active']}건 / 익명화 완료 {stats['anonymized']}건\n"
            f"현재 보관 정책: 체크아웃 후 {days}일"
        ), font=("맑은 고딕",10), justify="left").pack(padx=16, anchor="w")

        ttk.Separator(win).pack(fill="x", padx=10, pady=8)
        row = tk.Frame(win); row.pack()
        tk.Label(row, text="보관 기간(일):").pack(side="left")
        days_v = tk.IntVar(value=days)
        tk.Spinbox(row, from_=30, to=3650, textvariable=days_v, width=8).pack(side="left", padx=6)
        def save_policy():
            try:
                self.store.set_retention_policy(days_v.get())
                messagebox.showinfo("저장 완료",f"보관 기간이 {days_v.get()}일로 설정됨",parent=win)
            except ValueError as e: messagebox.showerror("오류",str(e),parent=win)
        tk.Button(win,text="정책 저장",command=save_policy,bg="#2980b9",fg="white").pack(pady=6)

        ttk.Separator(win).pack(fill="x", padx=10, pady=4)
        def run_anon():
            n = self.store.anonymize_old_records()
            self.auth.log_action("anonymize", f"{n}건 익명화")
            messagebox.showinfo("완료",f"{n}건 익명화 처리됨",parent=win)
            win.destroy()
        tk.Button(win,text="⚠️ 지금 익명화 실행",command=run_anon,
                  bg="#e74c3c",fg="white",padx=12,pady=6).pack(pady=6)
        tk.Label(win,text="※ 보관 기간 초과 이력의 고객명·전화번호를 [익명]으로 대체합니다.",
                 fg="gray",font=("맑은 고딕",8)).pack()


# ─────────────────────────────────────────────────────────────────────────────
def main() -> None:
    db_path = Path(__file__).with_name("motel_manager.db")
    store = MotelStore(str(db_path))
    root = tk.Tk()
    MotelManagerApp(root, store)
    root.mainloop()


if __name__ == "__main__":
    main()
